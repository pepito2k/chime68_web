# Changelog

Every `feat:` or `fix:` PR bumps the version and adds its own entry here, under
a heading for the new version. A heading without a date hasn't been released
yet; the date goes in when that version is tagged. See
[CONTRIBUTING.md](CONTRIBUTING.md#versions-and-the-changelog).

## [0.89.1] - 2026-11-18

### Bug Fixes

- **chime68:** the macOS release builds, Chime68.app and the command-line `chime68`, are signed with a Developer ID and the hardened runtime and notarized by Apple, so macOS 15 opens them without a trip to Privacy & Security; builds with Rust 1.100

## [0.89.0] - 2026-10-26

### Features

- **chime68:** a disk activity light: Window › Show Disk Activity (on by default, kept in `display.cfg`) puts a light in the Mac's window's title bar (on a Mac host a small lit rectangle at the right, like the one on Apple's old hard disks; elsewhere a coloured dot in the title), dark while the disks are idle, that turns green while a floppy, SCSI or IDE hard disk, CD-ROM or the built-in driver's volume is read and amber while one is written, held on for 120 ms so a single sector shows, and puts a badge on the Dock icon while the window is minimized or covered. It's in the title bar rather than on the Mac's screen, so screenshots, GIF and MP4 recordings and `--screenshot` are as they were; the SCSI Ethernet adapter's packets don't light it

## [0.88.4] - 2026-10-26

### Bug Fixes

- **macplus:** the PowerBook 165c and 180c sleep and wake: their LCD's driver answers System 7.5's GetSleepWake with 'slwk' (the System took a screen whose driver isn't one of Apple's built-in ones for a dock it can't sleep in), and only the GSC's panel ID, which the ROM reads to tell them from the grayscale models, bus-errors now, as the 180's sleep code they share saves the GSC's other registers

## [0.88.3] - 2026-10-26

### Bug Fixes

- **macplus:** a Duo Dock's floppy drive reads 720K floppies: its SWIM II's accesses take half a microsecond, as the Quadras' SWIM's do, so the Duo's .Sony no longer gives up on a byte (720K's come every 32 µs) before it arrives

## [0.88.2] - 2026-10-26

### Bug Fixes

- **macplus:** a Duo in its Duo Dock (`--second-monitor`) has the dock's floppy drive: a SuperDrive on a SWIM II, which the Duo's address map no longer hides, an ISM from the start that picks the head itself, and that sends a write's bytes out with no disk in (the Duo's .Sony times one at startup, and waited forever for it); 1.44 MB and 800K floppies mount, take writes and eject

## [0.88.1] - 2026-10-26

### Bug Fixes

- **macplus:** the PowerBook 165c and 180c say which they are: Gestalt's machine type is 50 and 71 (and the box flag 44 and 65) instead of the 180's 33, set by their video card's secondary init once the System starts, as the ROM's backlight driver can't take either box flag earlier

## [0.88.0] - 2026-10-26

### Features

- **macplus, chime68:** the PowerBook 165c and 180c (`--model pb165c`, `pb180c`): the 160's ROM with a colour LCD, 640x400 or 640x480 in up to 256 colours, Chime68's video card standing in for their VGA chip and its declaration ROM in slot $C (its driver runs the slot's VBL tasks from the VBL queue, as the PowerBooks take no slot interrupts); and a Duo takes a second monitor (`--second-monitor`, or Second in the setup window) in a Duo Dock's first NuBus slot, its interrupts on the MSC's slot lines

## [0.87.0] - 2026-10-26

### Features

- **chime68:** a ROM folder in the setup window: Macs... lists every Mac Chime68 runs, the ones with a ROM in the folder (`roms` on the desktop, or one picked with Folder..., which the setup remembers) to click, so a Mac is picked by name instead of by its ROM file; the folder is looked through once, and ROMs are known by their checksum

## [0.86.0] - 2026-10-26

### Features

- **m68k, macplus:** A/UX 3.0 runs on the Quadra 700, and installs from its CD onto a blank disk image: the 68040's access error frame names the space a MOVES faulted in (A/UX's page fault handler looped on it); the 53C96 holds a DMA transfer's interrupt until its bytes have left the FIFO or would have crossed the bus; the mouse finds A/UX's low memory under the 68040's user root pointer, and the Mac OS's again after A/UX restarts into it; a probe of A/UX's tables no longer leaves a bus error behind for the CPU; and a blank image that the Mac partitions itself (A/UX's installer, Apple HD SC Setup) becomes the whole disk, its partition map saved to the file

## [0.85.0] - 2026-10-26

### Features

- **m68k, macplus, chime68:** A/UX 3.0 runs on the IIci and the SE/30, to its login window, Finder and CommandShell: MOVES reads and writes the space SFC or DFC names through the MMU (A/UX copies to and from processes with it under a supervisor root pointer), with its address worked out in the supervisor's; the mouse finds the A/UX Toolbox's low memory in its process's space; and `chime68 disk bootable` makes a partitioned CD image, such as the A/UX 3.0 CD, start up as a hard disk

## [0.84.1] - 2026-10-26

### Bug Fixes

- **chime68:** the Intel macOS build starts again: it links the Swift runtime's CoreMedia library (for the camera) by `@rpath`, and now carries `/usr/lib/swift` to find it in

## [0.84.0] - 2026-10-26

### Features

- **m68k:** the 68020, 68030 and 68040 Macs translate their code on x86-64 hosts too (Intel Macs and Linux PCs): the same block translator as on AArch64 emits x86-64 code through an assembler with AArch64's operations, its registers homed in x86-64 ones or a stack frame and its flags kept to AArch64's meaning; cycle-for-cycle the same as the interpreter; `--no-jit` turns it off. An Intel build running under Rosetta leaves it off, as Rosetta makes the translated code slower than the interpreter there

## [0.83.0] - 2026-10-26

### Features

- **macplus, chime68:** SCSI Ethernet for the Macs without a slot for a card (the Plus, SE, Classic, Portable, PowerBooks, LCs and Classic II): `--ethernet` and `--internet` put an emulated DaynaPORT SCSI/Link on the highest free SCSI ID, the adapter BlueSCSI and PiSCSI emulate, so Dayna's driver gives MacTCP and Open Transport Ethernet; `--internet` on these Macs is Ethernet now, and PPP is `--modem ppp`

## [0.82.0] - 2026-10-26

### Features

- **chime68:** snapshot history: with `--snapshot`, Disk Options takes named snapshots of the disks (Take Snapshot...), rolls back to one and restarts (Roll Back to Snapshot...), branches from one after keeping where the disks were (Branch from Snapshot...) and shows them as a tree (Snapshot History...); they're kept in `IMAGE.snapshots/` beside each image, a commit keeps them good, and the control socket has `snapshot list`, `take`, `rollback`, `branch` and `delete`

## [0.81.0] - 2026-10-25

### Features

- **macplus, chime68:** Translate Keyboard Layout follows the host's real layout: the Mac takes the matching layout from its System, as its Keyboard control panel would (Español ISO for a Spanish or Latin American keyboard, and the U.S. System 7's others), and characters are typed with the keys and dead keys of the layout the Mac has, read from its `KCHR`, rather than the U.S. layout's; the macOS input source, Windows layout or X layout is followed as it changes, or `layout = NAME` in `keyboard.cfg` stands in for it

## [0.80.0] - 2026-10-25

### Features

- **macplus, chime68:** the Quadra 840AV's and 660AV's video input, from the host's camera: the decoder (SAA7191) and scaler (SAA7186) on Cuda's IIC bus, which now leaves devices that aren't there unacknowledged; Civic digitizing each field into its video RAM's video plane (16-bit, at `$100800`) with its digitizer interrupt (VDCInt, on the slot line with the blank's) and freezing for grabs; and the DAC showing the plane through the palette entries keyed for it in the video window, its other table's writes left out of the palette. Cuda answers the System's read of its version (2.35), which Gestalt `cuda` and Apple Video Player need. The screen's width follows Civic's divided graphics clock. Apple Video Player shows the camera live and copies frames; the camera runs only while the Mac digitizes; `--video-in PICTURE` gives a still instead, `--no-camera` none

## [0.79.0] - 2026-10-25

### Features

- **chime68:** resume where you left off: a running Mac's state (disks and all) is kept every three minutes, compressed and written on a thread of its own, and when Chime68 quits, beside its saved configuration (`NAME.resume`, or `Resume/unnamed.resume` for a setup without a name); the setup window then offers Resume beside Start, a configuration started at once (a desktop icon's) asks, and `--resume` resumes without asking; a Mac that was shut down starts afresh

## [0.78.0] - 2026-10-25

### Features

- **chime68:** Create empty disk... in the setup window, next to Add SCSI disk...: a pop-up of the Disk Options menu's hard disk sizes (20 MB to 2 GB) makes a blank, formatted HFS disk where you save it and adds it to the hard disk list

## [0.77.0] - 2026-10-25

### Features

- **m68k, macplus:** the 68020 and 68030 Macs translate their code to the host's too (the Mac II, LC, SE/30, IIx, IIcx, IIci, IIsi, IIfx, IIvx, LC II and III, Classic II, Color Classic and the 68030 PowerBooks), through their PMMU or the Mac II's 24-bit mode: blocks are kept by the address after the board's 24-bit translation, so a handle's flags in the top byte don't hide a write to code, and the TLB of RAM pages is emptied when the MMU's registers change, its cache is flushed or the mode switches; cycle-for-cycle the same as the interpreter, about 1.7x faster at the Finder

## [0.76.0] - 2026-10-25

### Features

- **m68k, macplus:** the 68040 Macs translate their code to the host's on AArch64 hosts (Apple Silicon): blocks of 68040 instructions become native code, kept by physical address and dropped when written over, with the interpreter running what isn't translated from within a block; cycle-for-cycle the same as the interpreter (devices see the same timing), about 3.5x faster at the Finder and 1.5x through a boot; `--no-jit` turns it off

## [0.75.3] - 2026-10-25

### Bug Fixes

- **m68k:** the two words after a RESET come from the prefetch queue, as on the real CPU, so Special › Restart on a Plus with System 6.0.8 restarts instead of running into empty memory (its restart code runs `reset; jmp (a1)` from RAM, which the ROM overlay covers once the reset line goes)

## [0.75.2] - 2026-10-25

### Bug Fixes

- **macplus:** with the Sound control panel's Sound Out rate at 22.050 or 44.100 kHz, the 840AV and 660AV no longer play alerts and other sounds about 9% fast: the DSP's BIO2 now switches the sound engine to the 22.5792 MHz clock (22.05, 29.4 and 44.1 kHz), as the hardware does

## [0.75.1] - 2026-10-25

### Bug Fixes

- **macplus:** 1.4 MB floppies are readable on the Quadra 700 (and writable: Erase Disk works): a SWIM access on the Mac II family now takes half a microsecond however fast the CPU is, so the floppy driver's wait for the next disk byte no longer runs out on a 68040 before the byte comes

## [0.75.0] - 2026-10-25

### Features

- **chime68:** a mail bridge for `--internet`: with `--mail-pop`, `--mail-imap`, `--mail-smtp`, `--mail-user` and `--mail-password` (or the same in a saved configuration), the Mac's POP3, IMAP and SMTP connections in the clear go to the account's servers over TLS (or STARTTLS), logged in with the account's name and password, so Eudora and Claris Emailer reach today's mail services

## [0.74.0] - 2026-10-25

### Features

- **chime68:** Software › Find Software Online searches the Macintosh Garden and the Internet Archive's Mac software, lists a title's disk images and archives, and downloads one into `~/Desktop/roms/garden` (or a folder of your choosing) and mounts it, as `chime68 software search|files|get` does from a shell; zip archives now become disks too (with the Finder information and resource forks of their `__MACOSX` files), and a zipped CD's cue sheet and tracks are unpacked for the CD-ROM drive

## [0.73.1] - 2026-10-25

### Bug Fixes

- **chime68:** on macOS the host's arrow no longer shows beside the Mac's pointer while the mouse moves: it's hidden with AppKit's own cursor hiding while it's over the Mac's screen, and shown again when it leaves the window or another app comes to the front

## [0.73.0] - 2026-10-25

### Features

- **macplus, chime68:** Disk Options › Browse Disk Image looks inside a disk image without starting a Mac: its HFS volume's files and folders in a window, files saved out as MacBinary, and host files added in (Add Files or dropped on the window, MacBinary and BinHex unpacked), written into the volume in place so it still starts up; `chime68 disk ls|get|put` does the same from a shell, for bare volumes, partitioned disks and DiskCopy 4.2 floppies

## [0.72.0] - 2026-10-25

### Features

- **chime68:** the `ppp` modem dials hosts: `ATDT bbs.example.com[:port]` in ZTerm or any terminal program opens a TCP connection there, telnet's negotiation answered for a VT100, with `+++`, `ATO` and `ATH` as on a Hayes modem and NO CARRIER when the host hangs up; a phone book (`phone = NUMBER HOST[:PORT]` in a configuration, or `--phone NUMBER=HOST[:PORT]`) sends numbers to hosts, and other numbers still reach the PPP provider

## [0.71.0] - 2026-10-25

### Features

- **chime68:** scripting: `--control PATH` (or `tcp:PORT`) opens a control socket, `--headless` runs the Mac without a window, and `chime68 ctl` sends commands to it: boot a saved configuration, move the pointer, click, drag, type, press keys and chords, choose menu items by name, wait for a pixel or for text on the screen (found by drawing it in the ROM's own fonts), and save PNG screenshots; `ctl run` runs a script of them and stops at the first failure, for smoke tests in CI

## [0.70.0] - 2026-10-25

### Features

- **chime68:** gamepads: a host game controller (through gilrs) moves the mouse, presses the arrow keys or presses keys chosen for the game, and each button clicks or presses a key; the Gamepad menu picks the mode and binds a control by pressing it and then the key, and the mapping is kept with the configuration (`gamepad`, `gamepad_keys`), so each game's saved configuration has its own

## [0.69.0] - 2026-10-25

### Features

- **macplus, chime68:** the Mac's Speech Manager said by the host's voices: Chime68 catches the Speech Manager's `_SoundDispatch` calls (and Gestalt's `'ttsc'`) before the trap is taken and answers them itself, with MacinTalk's 23 voices, channels with their own rate, pitch and volume, and `SpeechBusy` and the channel status following the host, which says the text with `say` on macOS (in the voice of the same name), `espeak-ng` on Linux and its speech synthesizer on Windows. SimpleText's Speak All and Voices menu, HyperCard's `speak` and PlainTalk programs talk on any Mac with System 7, a Plus included; Machine › Speak Aloud and `--no-speech` leave the Mac to its own

## [0.68.0] - 2026-10-25

### Features

- **chime68:** a LaserWriter: `--printer laserwriter` (or LaserWriter on the printer port in the setup window) puts "Chime68 LaserWriter" on the printer port's LocalTalk, in the Chooser beside the ImageWriter. It speaks PAP, answers the LaserWriter 7 and 8 drivers' queries as a LaserWriter II NT, and runs each job in a PostScript interpreter of its own that draws into a PDF on the Desktop: paths and pictures as they are, text in the printer's 35 fonts as real text in PDF's standard fonts, and the fonts the Mac sends (Type 3 bitmaps, Type 1 outlines) drawn from their own programs

## [0.67.0] - 2026-10-25

### Features

- **chime68:** dial-up Internet on the modem port: `--modem ppp` (or Internet on the modem port in the setup window, or `--internet` on a Mac without Ethernet) is a Hayes modem that answers its script's commands, says CONNECT and then speaks PPP (LCP, IPCP handing out the address, PAP taking any password) or SLIP to the Mac, carrying its packets to the `--internet` NAT and its web requests to the web proxy, so Open Transport PPP, MacPPP and FreePPP on a Plus, SE, Classic or PowerBook reach the Internet

## [0.66.0] - 2026-10-24

### Features

- **chime68:** a built-in AppleShare server: `--appleshare FOLDER` (or File › Share Folder over AppleShare...) shares host folders as volumes of the server "Chime68", which the Chooser's AppleShare finds on LocalTalk (LToUDP) and mounts as a guest. It claims a LocalTalk node, answers NBP lookups, speaks ATP (exactly-once responses kept until released) and ASP (sessions, commands, WriteContinue for writes, tickles), and serves AFP 2.1 on the host folders: browsing, reading and writing both forks, Finder information, making, renaming, moving and deleting (`appleshare`, `appleshare::afp`). The Mac's printer port goes on LocalTalk with it when free

## [0.65.0] - 2026-10-24

### Features

- **macplus, chime68:** rewind: F7 (Machine › Rewind 3 Seconds) goes back three seconds, again for three more, up to ten. A rewind point each second is a save state without the disks (`MacPlus::rewind_point`, compressed on another thread), and the hard disks, the built-in volume and the IDE disk journal what each write overwrites, so going back undoes those writes too and saves them to the images (`MacPlus::rewound`, `rewind::Journal`); RAM and video RAM now serialize as bytes, a copy's speed, in the same format. And screen recording: Shift-F6 (Window › Record Screen as GIF) writes an animated GIF of the changed parts of each third frame, in their own colours, and Window › Record Screen as MP4 a video with the sound through ffmpeg (`recorder`)

## [0.64.0] - 2026-10-24

### Features

- **macplus, chime68:** pictures on the shared clipboard both ways: a host image goes to the Mac as a PICT (256 colours with Color QuickDraw, dithered black and white without; `picture`), and a picture the Mac copies is drawn by the Mac's own QuickDraw in an errand (`DrawPicture` into a 32-bit `GWorld`, or a one-bit port without 32-bit QuickDraw: `host::Errand::DrawPicture`) and goes on the host's clipboard as an image. And sound input: the ASC's record mode (`$80A`), which fills FIFO A from the microphone at 22 or 11 kHz and interrupts at half full, as System 7's `.AppleSoundInput` expects on the IIsi, LCs, PowerBooks and Quadras, and the AVs' PSC input frames; the host's default microphone feeds them while the Mac records (`audio::Microphone`), unless Machine › Use Microphone is off

## [0.63.0] - 2026-10-24

### Features

- **chime68:** a web proxy for `--internet`, on unless `--no-web-proxy` is given, and turned off and on with Machine › Web Proxy: the Mac's requests to port 80 (and any to 10.0.2.4, for a browser set to use a proxy) are fetched over HTTPS where the server takes it and over HTTP where it doesn't (rustls, with the Mozilla roots), and answered in HTTP/1.0 with only the headers old browsers know. Pages lose their scripts, style sheets, SVG, inline frames and modern attributes, `https://` links become `http://` ones, late-loading pictures get their real address, newer block elements become `div`s and the text comes as ISO 8859-1 with what Latin-1 lacks written as ASCII; pictures over 640x800 are shrunk, and PNG, WebP and progressive JPEG become GIF or baseline JPEG (`webproxy`), so Netscape 2 and iCab can browse today's web

## [0.62.1] - 2026-10-24

### Bug Fixes

- **chime68:** the host's pointer showed beside the Mac's: over the black borders around the screen (where the Mac's pointer stayed put), when the screen moved or changed size under a pointer at rest (a Quadra 630 switching its video on, a resize, the Window menu's scaling), and when the host showed its cursor itself (another app, a dialog) and Chime68 thought it still hidden. The host's pointer is now hidden all over the window but the drawn menus, the Mac's following it to the edge of the screen over the borders, and it's worked out again whenever the picture changes or the window comes back to the front

## [0.62.0] - 2026-10-24

### Features

- **macplus, chime68:** MIDI on a serial port: `--modem midi` (or MIDI on the setup window's modem port) plugs in a MIDI interface that clocks the port at 1 MHz, which the SCC divides for MIDI's 31,250 baud (`scc::Link::clock_hz`), and passes the bytes to CoreMIDI: through a source and a destination called "Chime68", or with `midi:NAME` straight to a device, both ways, cut into whole messages for it (`midi::Parser`). And Machine › Translate Keyboard Layout: keys that type a character on the host type that character on the Mac's U.S. layout, with Shift, Option and its dead keys as it needs (`keymap`), so a Spanish keyboard types ñ, á and ¿ where it says

## [0.61.0] - 2026-10-24

### Features

- **chime68:** display polish in the Window menu, kept from run to run: Whole-Number Scaling (as before) or the picture as big as the window allows, keeping the screen's shape (Keep Aspect Ratio) or stretched to the window; a CRT Look, with dark lines between the rows, a slightly curved face darker towards the corners, and a little phosphor glow (`display::Crt`); and Save Screenshot (F6), the Mac's screen at its own size as a PNG on the desktop. `--screenshot` writes a PNG too, when its name ends `.png`

## [0.60.0] - 2026-10-24

### Features

- **chime68:** snapshot disks: with `--snapshot` (or Disk writes: Snapshot in the setup window) the images are never written; what the Mac writes goes to `IMAGE.snapshot` beside each, kept from run to run, until Disk Options' Commit Snapshot writes it to the images or Discard Snapshot and Restart throws it away (`storage::Writes`, `storage::commit`, `storage::discard`). StuffIt archives (classic and StuffIt 5, methods 0, 1, 2, 3, 13 and Arsenic, CRCs checked), BinHex and MacBinary files and DiskCopy 6 images (raw, zero and ADC chunks) given as disks or dropped on the window are unpacked to a plain disk image beside them and mounted: the disk image an archive holds, or a new HFS disk with its files, types, creators and resource forks (`convert`)

## [0.59.0] - 2026-10-24

### Features

- **chime68:** saved configurations: the setup window's new Configuration menu saves the setup under a name (Save Configuration, Save Configuration As...), lists the saved ones and the last six setups started, and takes any of them back; `--profile NAME` (or `--profile FILE.chime68`) starts one straight away, other options changing it, and quitting that Mac quits. On macOS, Put on Desktop makes a little app on the desktop, under Chime68's icon, that starts the configuration when double-clicked, whether Chime68 runs from Chime68.app or from a checkout; and Chime68.app opens `.chime68` files, starting them

## [0.58.0] - 2026-10-24

### Features

- **macplus, chime68:** two floppy drives at once: the IWM and SWIM now have drive 2 as well (the external drive, or the Mac II's second internal one), on SELECT or the ISM's drive bits, the drive picked trading places with the other (`Iwm::insert_in`, `eject_from`, `disk_in`, `MacPlus::insert_disk_in`). `--disk` may be given twice, a floppy dropped on the window or made with Disk Options goes in the first empty drive, and File has Eject Floppy 1 (F8) and Eject Floppy 2 (Shift-F8). Save states keep which drive each floppy is in

## [0.57.0] - 2026-10-24

### Features

- **macplus, chime68:** a Disk Options menu in the host menu bar: new blank 400K (MFS on the 128K and 512K, HFS elsewhere), 800K and 1.4 MB floppies and 20 MB to 2 GB hard disks, formatted so the Mac mounts them without asking to initialize them, saved where the user says and mounted at once; and Mount Disk Image. A hard disk (or a shared folder) attached while the Mac runs now mounts without a restart: a new host errand, `LoadDriver`, loads Chime68's SCSI driver for its HFS volume into the system heap and runs its install code, as the ROM's loader does at startup (`MacPlus::mount_scsi_disk`). `hfs::format` and `hfs::format_mfs` make blank volumes

## [0.56.0] - 2026-10-23

### Features

- **macplus, chime68:** the shared host folder is live both ways: what changes in the folder on the host while the Mac runs (files added, changed, deleted or renamed, folders added or deleted) goes on the volume through the Mac's own File Manager (new host errands `PutFile`, `MakeFolder`, `Delete` and `Flush`, on the volume told by its creation date), so the Finder's windows follow; and what the Mac deletes or renames there is deleted or renamed in the folder, once two looks agree it's gone and the catalog's counts add up, and only if the host copy hasn't changed. `--read-only` now still shows host changes on the Mac, and never changes the folder. `hfs::Volume::consistent` tells a catalog the Mac has only half written out

## [0.55.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh PowerBook 540c (2 MB ROM `B6909089`; `--model pb540c`), mapped from its ROM's decoder table: a 68LC040 at 33 MHz with VIA1 and VIA2, the SCC, the Enhanced ASC and the SONIC at a Quadra's addresses, the 5380 and SWIM, the CSC driving a 640×480 colour LCD (its blank on VIA2's slot $E line), the board ID `$A55A1808`, and the PG&E with its handshake on VIA2's port B. The PG&E answers the smart battery command (`$6F`). 4 to 36 MB. System 7.5.3 and Mac OS 7.6.1 boot to the Finder with the startup chime, and Shut Down switches it off

## [0.54.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh PowerBook 150 (ROM `FDA22562`; `--model pb150`): the Duo 230's MSC and PG&E with a 68030 at 33 MHz and no FPU, the GSC driving a 640×480 LCD in 16 grays, and an IDE hard disk inside, wired as the Quadra 630's but interrupting on the MSC's slot $D line (`--ide`, or the setup window's IDE disk). 4 to 40 MB. System 7.5.3 boots from SCSI and Mac OS 7.6.1 from the IDE disk. `Model::is_duo` is now `has_msc`

## [0.53.0] - 2026-10-23

### Features

- **macplus:** the Quadra 840AV's and 660AV's DSP3210, so their alert sounds and the Sound control panel's play: a port of MAME's DSP3210 core (its integer and floating-point units, delayed branches and DAU latencies, interrupts, timer and BIO pins), running on the Mac's RAM and, through an alias at `$F0000000`, its I/O; the PSC holds it in reset until the System lets it go, gives it the frame interrupt on IR1 and takes its doorbell on BIO0. The PSC's sound registers now take long writes whole, which put the System's sound buffer at the right address

## [0.52.0] - 2026-10-23

### Features

- **macplus, chime68:** a Mac given only disks with a System newer than it runs stops before it starts, with an alert that names the System and the newest one the Mac runs, rather than at a Sad Mac (Mac OS 7.6.1 on the Portable gave Sad Mac `0000000F`): Mac OS 7.6 and later on the 68000s, Mac OS 8 on the 68020s and 68030s and System 7 on the 512Ke. `hfs::system_version` reads the version from the System file in a disk's blessed folder

## [0.51.0] - 2026-10-23

### Features

- **macplus:** the Quadra 840AV's and 660AV's built-in Ethernet: the MACE chip, its FIFOs filled and emptied by the PSC's DMA channels a frame at a time, with its address ROM read a byte every 16 bytes as on the board. AppleTalk over Ethernet starts on Mac OS 7.6.1, its loopback self-test included, and `--ethernet` and `--internet` work on them

## [0.50.0] - 2026-10-23

### Features

- **chime68:** the setup window takes the Quadra and LC 630's and the LC 580's IDE disk: it heads the hard disk list as "IDE", with a Choose IDE disk... button and a File menu item, and is saved with the rest of the setup. Other Macs leave it out

## [0.49.4] - 2026-10-23

### Bug fixes

- With the fast memory test on, the startup chime plays to the end: the speed-up waits until the chime has finished, up to five seconds, instead of always starting after one second, which cut off the longer chimes of the Quadras, the LC III, the Color Classic and the AV Macs.

## [0.49.3] - 2026-10-23

### Bug fixes

- The Mac II family's alert sounds play every time, not just the first: the Apple Sound Chip's stereo switch is bit 1 of its control register, not bit 0, so in stereo FIFO B filled up and stayed full.

## [0.49.2] - 2026-10-23

### Bug fixes

- The Portable, the PowerBook 100 and the Duos keep their PRAM between runs: it is in their power manager, not the clock chip, and was saved blank. `--screenshot` saves the Portable's whole screen.

## [0.49.1] - 2026-10-23

### Bug fixes

- **macplus, chime68:** a Mac whose screen changes size as it runs no longer stops Chime68: the window follows it (the Quadra 800's video driver set a 256×768 mode for a frame while setting its own up, which panicked at 136 MB), and DAFB now only shows a monitor's own modes

## [0.49.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Quadra 840AV and 660AV (2 MB ROM `5BF10FD1`; `--model q660av` for the 660AV), the first 2 MB ROM: 68040s at 40 and 25 MHz with YMCA; the PSC, with VIA1 and Cuda, its pseudo-VIA2, its interrupt registers for levels 3 to 6, the DMA engine the 53C94 moves its data through, and its sound engine, which plays the startup chime from the ROM; and Civic's video, up to millions of colours on a 13" monitor. 8 to 128 MB. System 7.5.3 boots to the Finder with the mouse and keyboard, and Shut Down switches it off. Not yet: the DSP3210, so the System's own sounds, the MACE Ethernet chip and the New Age floppy controller

## [0.48.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Quadra and LC 630 (ROM `06684214`; `--model lc630` for the LC, without an FPU) and LC 580 (`064DC91D`): 33 MHz 68040s with F108, whose RAM banks the ROM moves as MEMCjr's (4, 8, 12, 20 or 36 MB); Valkyrie's video, up to thousands of colours on a 13" or 12" RGB monitor; PrimeTime II's I/O with the 53C96 and Cuda; and the internal IDE disk, `--ide <image>`, written back as SCSI disks are and kept in save states. Mac OS 7.6.1 boots to the Finder from an IDE disk, and System 7.5.3 from a SCSI one, with the startup chime, the mouse and keyboard and the alert sounds, and Shut Down switches it off

## [0.47.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Quadra 800, 650 and 610 and Centris 650 and 610 (ROMs `F1ACAD13` and `F1A6F343`; `--model q650`, `q610`, `c650` or `c610`): 20 to 33 MHz 68040s (the Centrises' 68LC040s) with djMEMC, whose DAFB drives the same monitors as the Quadra 700's and whose ten banks of RAM go where the ROM puts them (8 MB on the board, 4 on the 610s, and SIMMs in banks of powers of two); and IOSB, with the RTC and ADB on VIA1, the model on VIA1's port A, a board ID, the 53C96, Ethernet and the Enhanced ASC. System 7.5.3 boots to the Finder with the startup chime, the mouse and keyboard and the alert sounds, and Shut Down switches it off. MEMCjr's banks on the Quadra 605 work the same way now

## [0.46.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Quadra 605 and LC 475 (ROM `FF7439EE`; `--model lc475` for the LC): 25 MHz 68040s (the LC 475's a 68LC040, without an FPU) with MEMCjr, whose DAFB takes its twelve-bit registers six bits at a time and whose five banks of RAM go where the ROM puts them; PrimeTime's I/O, with the 53C96's DMA port, its DRQ on VIA2, and a board ID; Cuda; and the Enhanced ASC. 4, 8, 12, 20 or 36 MB, and the 13", 16", 15" Portrait and 21" monitors. System 7.5.3 boots to the Finder with the startup chime, the mouse and keyboard, the clock and the alert sounds
- **macplus:** Cuda's one-second mode 3 sends the time each second, as GET_TIME's reply, which the Quadra 605's ROM keeps the clock by; and the LC III's and Color Classic's sound plays its FIFOs as Sonora's does (MAME's `asc_sonora_device`)

## [0.45.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Color Classic (ROM `ECD99DC0`): V8's machine as Spice, in a compact case with its own 512×384 colour screen (up to thousands of colours), the Enhanced ASC, and Cuda, Egret's successor, with its handshakes (TIP, the byte acknowledge and TREQ, the sync at startup, and the one-second tick only once asked for). Spice's memory configuration puts the SIMM at 0 and the board's 4 MB after it, as the ROM says; 4, 6, 8 or 10 MB. System 7.5.3 boots to the Finder with the startup chime, the mouse and keyboard and the alert sounds, and Shut Down switches it off

## [0.44.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh LC III (ROMs `ECBBC41C` and `EC904829`): a 25 MHz 68030 built around Sonora, with its board ID, Egret, video with 1 MB of its own in up to thousands of colours on a 13", 12" or Portrait monitor, the Enhanced ASC (version `$BC`), and its memory controller, which shows each bank in a 16 MB window of its own while the ROM sizes them and puts the SIMM after the board's 4 MB once told its size; 4, 5, 6, 8, 12, 20 or 36 MB. System 7.5.3 boots to the Finder with the startup chime, the mouse and keyboard and the alert sounds; Shut Down ends at "It is now safe to switch off your Macintosh"
- **macplus:** where logical address 0 is in RAM (for the cursor's low-memory globals) is no longer looked up with interrupts off, where the system may be halfway through loading the MMU's registers: on an LC III with 12 MB, a glimpse of the half-loaded table made the cursor's globals land elsewhere, and the system crash at startup

## [0.43.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Classic II (ROM `3193670E`): V8's machine with a 68030 in a compact case, its 512×342 screen at the end of the RAM on the board, and Egret. System 7.5.3 boots to the Finder, with the mouse and keyboard, and Shut Down switches it off. On the LC and Classic II, V8 now puts the 2 MB on the board at $800000-$9FFFFF and the SIMMs from 0, repeating; the LC and Classic II take 4, 6 or 10 MB, the LC II 4, 6 or 8

## [0.42.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh LC and LC II (ROMs `350EACF0` and `35C28F5F`): V8's 24-bit map, Egret with ADB, and video with 512K of its own in up to 256 colours or grays. System 7.5.3 boots to the Finder on both, with the mouse and keyboard
- **m68k:** the 68030's MMU checks its long descriptors' limits, refusing indexes past them; and the instructions after the PMOVE that turns translation on run from where they were, untranslated, as the 68030 has them in its pipeline (the LC II's ROM turns the MMU on from a 24-bit alias of itself, then jumps to its 32-bit address)

## [0.41.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh Portable (ROM `96CA3846`), on the PowerBook 100's machine, with 1 to 9 MB. System 7.5.3 boots to the Finder with the keyboard and trackball, and Shut Down switches it off

## [0.40.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh IIvx and IIvi (ROM `4957EB49`): the IIsi's machine at 32 MHz with a 68882 or at 16 MHz without, with three NuBus slots and VASP's video, 512K of its own at 1024 bytes a row, in 1 to 8 bits on a 13" or 12" RGB monitor. Their ROM is told VASP's decoder from the IIci's by VIA1 not repeating 256K up, sizes the SIMMs while it still runs from the overlay (which now ends only on a read of the ROM at `$40800000`), and plays the startup chime through the Enhanced ASC. System 7.5.3 boots to the Finder, with the mouse and keyboard and every depth in Monitors

## [0.39.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh IIfx (ROM `4147DD77`): a 68030 at 40 MHz on a map of its own, with the SCC and SWIM behind the Quadra 900's I/O processors (ADB on the SWIM's), the OSS interrupt controller in VIA2's place (which switches it off at Shut Down), and the SCSI DMA chip, whose engine and handshake mode move the disk's data. System 7.5.3 boots to the Finder, with the mouse and keyboard, and what's written to the disk stays

## [0.38.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh 128K and 512K, on their 64 KB ROMs (`28BA61CE` and `28BA4E50`; either runs in both, picked by name), and the 512Ke, on the Plus's ROM: the Plus without SCSI, with 128 or 512 KB. The Memory pop-up shows sizes under a megabyte in KB

## [0.37.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh IIsi (ROM `36B7FB6C`): the IIci's RBV video at 20 MHz, without FPU or slots, 1 to 17 MB, with Egret running the clock, the PRAM and ADB (autopolling it), and switching the Mac off at Shut Down. System 7.5.3 boots to the Finder, with the mouse and keyboard

## [0.36.0] - 2026-10-23

### Features

- **macplus, chime68:** the Macintosh IIx and IIcx, on the II FDHD's ROM (`97221136`): 68030s at 16 MHz with the 68882, a SuperDrive and the II's video card, 1 to 32 MB. Pick them in the Machine pop-up or with `--model iix` or `iicx`; the ROM knows them by VIA1's PA6 and VIA2's PB3, and reports them as such to Gestalt

## [0.35.0] - 2026-10-23

### Features

- **chime68:** the setup window shows the Mac's icon beside the Machine pop-up, in black and white: the Iconfactory's Apple Desktop and Apple Portables Collections (© 1998 the Iconfactory, used with permission), one for each Mac Chime68 runs

## [0.34.1] - 2026-10-22

### Bug fixes

- **macplus:** the PowerBook 160 and 180 see their floppy drive: the IWM's write handshake register reads its low six bits set, as the 160's and 180's `.Sony` checks to tell the IWM from the SWIM, where it read bit 5 clear and gave up on the drive
- **macplus:** the cursor hides while you type, as the system asks (ObscureCursor), on the Macs whose cursor task redraws whenever it's flagged (the Plus to the Quadras, the PowerBook 100, 140 and 170): Chime68 flagged it every frame, even with the host's pointer still

## [0.34.0] - 2026-10-22

### Features

- **macplus:** the Quadra 700's, 900's and 950's Enhanced ASC (version `$B0`): no wavetable, its FIFOs played at 44.1 kHz through its sample rate converters, with its CD-XA ADPCM decoder and the FIFOs' half-empty interrupts it enables per channel. The startup chime plays as before, and the alert sounds of System 7.5.3, Mac OS 7.6.1 and 8.1 now play every time, where 7.6.1 and 8.1 played only the first. Save states are format 25

## [0.33.0] - 2026-10-22

### Features

- **macplus, chime68:** the PowerBook Duo 270c (its ROM, `0024D346`) and the Duo 280 and 280c (theirs, `015621D7`; `--model duo280c`, or the Machine pop-up): the Duo 210's machine with the CSC, Apple's colour screen controller, in place of the GSC, with its CLUT, depths of 1 to 8 bits, its VBL interrupt and 512K of video RAM, and the panel the ROM picks the video modes by: the 270c's and 280c's 640x480 colour LCD, the 280's 640x400 one in 16 grays. The 270c is a 68030 with an FPU, the 280 a 68LC040 and the 280c a 68040. System 7.5.3 boots to the Finder, Gestalt says Duo 270c, 280 or 280c, Monitors switches the depth, and the battery, sleep and wake work as on the 210. 4 to 32 MB on the 270c, 4 to 40 on the 280s. Save states are format 24

## [0.32.0] - 2026-10-22

### Features

- **macplus:** the Duo 210, 230 and 250 have a battery: the PG&E answers the battery monitor's three commands (`6A`, `6B`, `6D`), so the menu bar shows its level and the charging bolt, it runs down off the adapter (`--battery`, the Machine menu) and charges on it, and the system warns on reserve power and puts the Duo to sleep when it's flat, as on the 140

## [0.31.2] - 2026-10-22

### Bug fixes

- **macplus:** the PowerBook 100 switches off at the end of a Shut Down, and Chime68 quits, instead of going to sleep. Its ROM sends the power manager the sleep command for both, and leaves `$CFC` clear when it means to shut down
- **macplus:** after a PowerBook wakes, the cursor follows the host's pointer again. Waking resets the CPU, and Chime68 then waited for the memory test that doesn't come on a wake before steering the cursor

## [0.31.1] - 2026-10-22

### Bug fixes

- **macplus:** on the PowerBook 160 and 180 and the Duos the cursor follows the host's pointer, instead of staying where it was drawn while clicks landed under the pointer. Their ROMs' cursor task redraws only when its point differs from `Mouse`, which Chime68 was writing itself; it now leaves `Mouse` to the cursor task

## [0.31.0] - 2026-10-22

### Features

- **chime68:** the setup window shows its errors (a disk or ROM it can't open, a ROM for another Mac, a memory size the Mac can't have) in a System 7 stop alert, wrapped over as many lines as they need, instead of a line by the buttons that cut them off. OK, Return or Enter dismisses it

## [0.30.0] - 2026-10-22

### Features

- **macplus, chime68:** the PowerBook 100 (its ROM, `96645F9C`; `--model pb100`, or the Machine pop-up): a 68000 at 15.67 MHz on a 24-bit map of its own, with the SWIM, the Apple Sound Chip, a VIA and a 640x400 LCD, and its power manager at the level of its commands, over the VIA's port A: ADB for the keyboard and trackball (with its own command to read the answers, and service requests from the device it isn't polling), the clock, PRAM, its memory, the battery, sleep and wake. System 7.5.3 boots to the Finder and Gestalt says PowerBook 100. 2 to 8 MB. Shut Down puts it to sleep, and a key or the trackball's button starts it again. Save states are format 23

## [0.29.0] - 2026-10-22

### Features

- **macplus, chime68:** the PowerBook Duo 210, 230 and 250 (their ROM, `ECFA989B`; `--model duo230` or `duo250`, or the Machine pop-up): the MSC's memory map, VIA1 and pseudo-VIA and the machine ID that tells the three apart, the GSC's grayscale LCD, and the PG&E power manager at the level of its commands, through VIA1's shift register: it takes the firmware the ROM sends it at startup, runs ADB for the keyboard and trackball (with the Duo ROM's autopolling), keeps the clock and PRAM, and sleeps, wakes and shuts down. System 7.5.3 boots to the Finder and Gestalt says Duo 210, 230 or 250. 4 to 24 MB. No dock (so no floppy drive), and the battery reads as missing. Save states are format 22

## [0.28.0] - 2026-10-22

### Features

- **macplus, chime68:** the PowerBook 160 and 180 (their ROM, `E33B2724`; `--model pb180` or the Machine pop-up for the 180): the 140's machine at 25 and 33 MHz (the 180 with a 68882), with Niagra in Jaws's place (its CPU speed, FPU and Ponti registers) and the GSC's 640x400 LCD in black and white, 4 or 16 grays. System 7.5.3 boots to the Finder, Gestalt says PowerBook 160 or 180, Monitors switches the grays, and sleep, wake, Shut Down and the battery work as on the 140. 4 to 14 MB. Save states are format 21

## [0.27.0] - 2026-10-22

### Features

- **chime68:** the debugger's window (Debugger in the Window menu, or `--debug window`): the code from the PC, where a click sets or clears a breakpoint; the registers and flags; the breakpoints and watchpoints; and memory from a typed address or a register's; with Run, Pause, Step and Step Over (which runs a JSR, BSR or trap through), beside the Mac's window in the setup window's System 7 look. It drives the same debugger as the console and GDB

### Bug fixes

- **chime68:** on the Mac II family the debugger's breakpoints, disassembly and memory dumps take 32-bit addresses, as the program uses them (through the MMU when it's on), instead of 24-bit ones, so a breakpoint in the ROM at `$408xxxxx` stops the Mac

## [0.26.0] - 2026-10-22

### Features

- **macplus, chime68:** the PowerBook 140 and 170 sleep, wake and shut down: Sleep (from the Special menu, or the system's when the battery runs out) darkens the screen and stops the Mac, a key or the trackball's button wakes it where it was (the PMU resets it and the ROM resumes from RAM), and Shut Down switches it off and quits Chime68. The battery runs down in two hours off the power adapter and charges in two on it: `--battery PERCENT` starts off the adapter with that much charge, and Power Adapter in the Machine menu plugs it in and pulls it out. The system's own warnings and its sleep at no reserve power work as on the real ones. Save states are format 20

## [0.25.0] - 2026-10-22

### Features

- **macplus:** the Quadra 900 and 950 take 4, 8, 16, 32, 64, 80, 96, 128, 192 or 256 MB (the default is now 16 MB), all four banks of SIMMs, which the memory controller puts one after the other from 0; Mac OS 7.6.1 and 8.1 see all of it. 20, 36 and 68 MB, the Quadra 700's sizes, are the Quadra 700's alone again. Save states are format 19

## [0.24.0] - 2026-10-22

### Features

- **macplus, chime68:** the IIci's cache card (`--cache-card`, or Cache card beside Memory in the setup window): Apple's 32K cache card in the cache connector, which the ROM switches on (the RBV's port B, bit 0) as it starts up, and which runs the IIci about a fifth faster while it's on. Save states are format 18

## [0.23.0] - 2026-10-22

### Features

- **macplus:** the compact Macs' VIA PB6 reads the horizontal blanking signal (H4), high for the 96 cycles at the end of each scan line, and their VIA accesses wait for the E clock (the CPU clock / 10) as on the 68000's synchronous bus, taking 9 to 18 cycles each instead of 4

## [0.22.1] - 2026-10-22

### Bug fixes

- **m68k:** a bus or address error while the CPU is taking another exception (stacking its frame or reading its vector) is taken as a bus or address error, flagged on the 68000 as not an instruction's, instead of halting the CPU; only a fault while taking a bus or address error itself (a double bus fault) halts it. The 68020/68030 bus fault frame gives a data fault's size and, for a write, its data (the data output buffer), and the 68040's access error frame its size

## [0.22.0] - 2026-10-21

### Features

- **chime68-web:** Chime68 in a web browser: `scripts/build-web.sh` builds the emulator as a WebAssembly module and a page (into `target/web`) that keeps ROMs and disk images picked with its file inputs in the browser's storage, runs the Mac on a canvas with the keyboard and mouse, plays its sound through Web Audio, and saves what the Mac writes to its disks and PRAM back to the browser. No networking. The native app is unchanged

## [0.21.0] - 2026-10-21

### Features

- **macplus, chime68:** CD audio: BIN/CUE images (`--cd game.cue`, with the BIN files the cue sheet names next to it, one file or a file per track) go in the CD-ROM drive with their audio tracks, and the drive plays them into the Mac's sound on the SCSI-2 audio commands Apple's CD-ROM driver sends (PLAY AUDIO by LBA, MSF time or track, PAUSE/RESUME, stop, READ SUB-CHANNEL's position and status, the full table of contents), at the volume the Mac sets through the audio control page; AppleCD Audio Player plays audio CDs. Save states are format 17

## [0.20.0] - 2026-10-21

### Features

- **macplus, chime68:** the Quadra 900 (`--model q900` with the Quadra 700's ROM, or the setup window's Machine pop-up) and the Quadra 950 (its own ROM): Egret for the clock, the PRAM, Restart and Shut Down (which switches the Mac off and quits Chime68); the SCC's and the SWIM's I/O processors, whose 65C02s run Apple's firmware, so ADB (driven bit by bit on the SWIM's I/O processor), the floppy drive (with its DMA) and the serial ports work as on the real machines; and the second 53C96. Mac OS 7.5.3 and 7.6.1 boot to the Finder on both. 4 to 68 MB (the other two memory banks, for up to 256 MB, aren't emulated yet). Save states are format 16

## [0.19.4] - 2026-10-21

### Bug fixes

- **macplus:** the Mac II, IIx, IIcx and IIci switch themselves off at the end of a Shut Down, as the real ones do, instead of showing "It is now safe to switch off your Macintosh"; **chime68** then quits, saving the disks and PRAM as Quit does

### Tried

Headless, on Mac OS 7.6.1 on the Quadra 700 and the IIci, and on Mac OS 8.1 on the Quadra 700:

- MacPaint 2.0 draws and quits; Lemmings 1.5.2 plays, in black and white and in 256 colours
- Monitors (Monitors & Sound on 8.1): black and white, 256 colours and millions on the Quadra, 256 on the IIci; Sound and Alerts
- Date & Time and Map: local time, the host's time zone, Montevideo found and set without moving the clock
- The Finder: copying a disk's contents to the hard disk, a new folder, Get Info; Restart; Shut Down (the Quadra 700 asks to be switched off, as it has no soft power)
- Internet Explorer 4 on 8.1 through `--internet` (TCP/IP on Ethernet with DHCP) loads pages over plain HTTP; HTTPS sites fail with "a secure connection could not be established", as on a real 8.1
- HyperCard 2.4.1 installs from its CD on 7.6.1, with QuickTime 3 and English Text-to-Speech, and runs: Home opens, Graph Maker draws its pie chart. The CD's installer asks for an "AppleScript Setup" disk it doesn't find on the CD; skipping that item installs the rest
- Photoshop 2.5.1 installs from its seven disk folders (onto a second hard disk, as its Installer 3.4 won't install onto the disk it runs from) and runs on 7.6.1: personalising, a new RGB image, the paintbrush and the pencil
- StuffIt Expander 5.5 installs and expands Photoshop, Prince of Persia, Dark Castle and NCSA Telnet; Prince of Persia and Dark Castle play
- NCSA Telnet 2.6 on 7.6.1 connects through `--internet` by name (telehack.com answers), once the TCP/IP control panel has made TCP/IP active; while TCP/IP is inactive it can't open a connection ("Couldn't make new TCP stream"), as on a real Mac
- MODE32 7.5 installs on System 7.5.3 on the SE/30, which then starts up with 32-bit addressing on. Mac OS 7.6.1 doesn't go further: its installer says it doesn't run on the SE/30 (Apple left the SE/30, Mac II, IIx and IIcx out of 7.6), and a 7.6.1 installed on another Mac stops at startup with a bus error on the SE/30 and "unimplemented trap" on the Mac II, with MODE32 installed

## [0.19.3] - 2026-10-21

### Bug fixes

- **macplus:** the Mac's clock keeps local time, as a real Mac's does, instead of starting on UTC (three hours ahead in Montevideo), and the Map control panel's location (Date & Time's time zone) starts in the host's time zone, so picking the place you are in no longer moves the clock. A location already set keeps its place and takes the host's GMT offset. **chime68:** a shared folder's file dates are local time too

## [0.19.2] - 2026-10-21

### Bug fixes

- **chime68:** Escape no longer quits Chime68; it goes to the Mac, where dialogs take it as Cancel. Quitting on it switched the Mac off without a Shut Down, and an unclean quit like that is what makes System 7.5 and later warn on the next start that the computer wasn't shut down properly. Quit with Command-Control-Q, the Quit menu item or the window's close button, after a Shut Down

## [0.19.1] - 2026-10-20

### Bug fixes

- **macplus:** the Mac's cursor keeps up with a fast host mouse instead of lagging behind it and jumping around: the host pointer now puts the cursor where it is, as the system's own cursor task would, rather than sending mouse steps that the system's mouse acceleration made overshoot

## [0.19.0] - 2026-10-20

### Features

- **chime68:** the setup window's Machine, Memory, Monitor and Second settings are System 7 pop-up menus: press one and its menu pops up over it with the setting checked, to drag to another and let go (or click, and click again); the Machine pop-up picks which Mac a shared ROM runs in, and one with nothing to choose is dimmed

## [0.18.0] - 2026-10-20

### Features

- **macplus:** Mac OS 7.6.1, 8.0 and 8.1 on the Quadra 700 (and 7.6.1 on the IIci): their install CDs start the Mac up, with the disc's HFS partition behind Chime68's driver until Apple's CD-ROM extension takes the whole disc over, and their installers install onto a hard disk image

### Bug fixes

- **macplus:** the Quadra 700's 53C96 sends a byte the ROM puts in its FIFO ahead of a DMA write first, as the ROM does for a buffer at an odd address, so writing a file from such a buffer no longer fails with an I/O error (which stopped the Mac OS 7.6.1 installer)

## [0.17.0] - 2026-10-20

### Features

- **macplus, chime68:** bigger monitors (`--monitor`, or Monitor in the setup window): 832×624, 1024×768 and 1152×870 on the Mac II's video card, Apple's 16", 15" Portrait and 21" on the Quadra 700's DAFB (by their sense codes), and the 12" and Portrait on the IIci; and a second monitor (`--second-monitor`, or Second) on a video card of its own in the Mac II, IIci and Quadra 700, shown in a second window

## [0.16.0] - 2026-10-20

### Features

- **macplus, chime68:** host integration: text copied on the Mac or the host pastes on the other, files dropped on the window that aren't disk images are copied onto the Mac's desktop by its own File Manager, and an ImageWriter on the printer port prints to PDF files (`--printer pdf`, or PDF in the setup window)

## [0.15.0] - 2026-10-20

### Features

- **chime68:** the Internet for the Mac (`--internet`, or Ethernet: Internet in the setup window): a user-space NAT like QEMU's slirp, with BOOTP/DHCP, a name server on the host's resolver, TCP and UDP through host sockets and ping, so MacTCP and Open Transport reach the Internet with no root and no setup
- **chime68:** a LocalTalk bridge (`--localtalk-bridge`, or LocalTalk bridge in the setup window): an AppleTalk router between LocalTalk over UDP and the Ethernet multicast group, so a Plus, SE or Classic on LocalTalk mounts AppleShare servers on EtherTalk

## [0.14.0] - 2026-10-20

### Features

- **macplus, chime68:** the PowerBook 140 and 170 (`--model pb140` or `pb170` with the Quadra 700's ROM, or the setup window's Machine pop-up): the 640×400 LCD, the power manager's ADB keyboard and trackball, its battery and parameter RAM, and processor cycling, booting System 7.5.3 to the Finder
- **m68k:** `MOVES` in CPU space bus-errors unless it reaches an FPU's coprocessor interface, as the ROM's test for an FPU expects

## [0.13.0] - 2026-10-20

### Features

- **macplus, chime68:** Ethernet (`--ethernet`, or Network in the setup window) on a UDP multicast group QEMU's socket netdev shares: the Quadra 700's built-in SONIC, and an EtherTalk NB-style card for the Mac II, IIci and SE/30, so AppleShare over EtherTalk and MacTCP run between Macs

### Bug fixes

- **macplus:** the Quadra 700's Ethernet address ROM holds each byte's bits fully reversed, as its driver reads them

## [0.12.0] - 2026-10-20

### Features

- **m68k, macplus:** the Mac II's 68851 PMMU, so System 7's virtual memory runs on the Mac II and II FDHD
- **m68k:** the 68881 (and the 68040's FPU) computes in its full 80-bit extended precision, correctly rounded in every rounding mode and precision, with the inexact, overflow and underflow flags

### Bug fixes

- **macplus:** the Startup Disk control panel lists the disks on Chime68's own SCSI driver

## [0.11.0] - 2026-10-20

### Features

- **macplus, chime68:** a CD-ROM drive (`--cd`, or CD-ROM in the setup window) for ISO, Toast and `.cdr` images: an AppleCD to the Mac, so System 7.5's install CD boots and Apple's CD-ROM extension uses it, and bare HFS discs mount even without it; eject from the Finder or the File menu

## [0.10.0] - 2026-10-20

### Features

- **macplus:** the Macintosh Quadra 700, on the 68040 with DAFB video and a 53C96 SCSI controller

### Performance

- **m68k, macplus:** the 68030 and 68040 Macs run 15 to 25% faster (MMU translations and RAM accesses take a shorter path)

## [0.9.0] - 2026-10-20

### Features

- **macplus:** System 7's virtual memory and 32-bit addressing on the SE/30 and IIci, and up to 128 MB of RAM on both

## [0.8.0] - 2026-10-20

### Features

- **chime68:** the emulator's and the setup window's menus are in the host's menu bar on macOS and Windows, leaving the windows to the Mac and the setup dialog

## [0.7.0] - 2026-10-20

### Features

- **macplus:** the Macintosh SE/30 and IIci, on the 68030 and its MMU

## [0.6.0] - 2026-10-20

### Features

- **chime68:** Chime68.app for macOS, with an icon, taking disks dropped on it

## [0.5.0] - 2026-10-20

### Features

- **chime68:** working menus in the setup window, and a menu bar in the emulator window

## [0.4.1] - 2026-10-20

### Bug Fixes

- **macplus:** the Mac II switches to 4, 16 and 256 colours on System 7.5

## [0.4.0] - 2026-10-20

### Features

- **chime68:** the setup window looks like a System 7 dialog, in a Chicago-style font

### Bug Fixes

- **chime68:** the GDB stub no longer loses packets on Windows after waiting for the Mac to stop

## [0.3.0] - 2026-10-20

### Features

- **chime68:** a setup window for the machine
- **chime68:** keep each model's PRAM between runs
- **chime68:** share a host folder with the Mac as a volume
- **m68k:** the 68020
- **macplus:** LocalTalk over the SCC, bridged with LToUDP
- **macplus:** run the Macintosh SE and Classic
- **macplus:** the Macintosh II, with a 68881 and a NuBus video card
- **macplus:** the SWIM and SuperDrive for 1.44 MB floppies

### Bug Fixes

- **macplus:** format 800K floppies on every model

### Performance Improvements

- batch the device ticks and take a fast path to RAM and ROM

## [0.2.0] - 2026-10-20

### Features

- **chime68:** a debugger with a disassembler, console and GDB stub
- **chime68:** add instruction trace to the headless runner
- **chime68:** event-driven window input with winit
- **chime68:** full screen, crisp scaling, disk drops and emulator keys
- **chime68:** full screen, whole-number scaling, disk drops and emulator keys
- **chime68:** real-time pacing and speed control
- **chime68:** run the power-on memory test at full speed
- **m68k:** accurate instruction cycle counts
- **macplus:** boot from floppy disk images
- **macplus:** boot hard disk volumes through a built-in disk driver
- **macplus:** boot the Mac Plus ROM to the question-mark disk
- **macplus:** emulate RTC, IWM sense lines, SCC and SCSI registers
- **macplus:** mouse and keyboard input
- **macplus:** save disk writes back to the image
- **macplus:** save states
- **macplus:** SCSI bus and hard disk target
- **macplus:** serial ports on the Z8530 SCC
- **macplus:** sound output
- **macplus:** video RAM contention

### Bug Fixes

- **chime68:** don't lose quick mouse clicks
- **chime68:** let the pacer skip frames below its starting count
- **chime68:** name the sound output device at startup
- **chime68:** play back mouse clicks the window missed
- **chime68:** refuse dropped floppies while the built-in volume driver is in use
