# Chime68

A classic Macintosh emulator written in Rust. It runs the compact 68000
Macs: the **Macintosh 128K**, **512K** and **512Ke**, the **Macintosh
Plus**, **SE**, **SE FDHD** and **Classic** (68000 at 7.83 MHz, up to 4 MB
RAM, 512×342 monochrome display, floppy, SCSI, VIA and SCC; the SE and
Classic with the Apple Desktop Bus), and the **Macintosh II** (68020 and
68881 at 15.67 MHz, 8 MB, a NuBus video card with a 640×480 screen in up
to 256 colours, the Apple Sound Chip), the **IIx**, **IIcx**, **SE/30**,
**IIci**, **IIsi**, **IIfx**, **IIvx** and **IIvi** (68030), the **LC**
(68020), **LC II**, **Classic II**, **Color Classic** and **LC III**
(68030), the **Quadra 700**, **800**, **650**, **610** and **605**, the
**Centris 650** and **610**, the **LC 475**, the **Quadra** and **LC 630**
the **LC 580** and the **Quadra 840AV** and **660AV** (68040), and the
**PowerBook 140**, **170**, **160** and **180** and the **PowerBook Duo
210**, **230** and **250** (68030, with a 640×400 LCD, in 16 grays on the
160, 180 and Duos), the **Duo 270c** (68030, a 640×480 colour LCD) and
**280** and **280c** (68040, in 16 grays or colour), the **PowerBook 150**
(68030, a 640×480 LCD in 16 grays and an IDE disk), the **PowerBook 540c**
(68LC040, a 640×480 colour LCD), and the **PowerBook 100** and **Macintosh
Portable** (68000).

Status: early. The 68000 core is largely complete and passes 99.6% of the
[SingleStepTests](https://github.com/SingleStepTests/680x0) 68000 suite; the
machine model boots real Plus, SE, Classic and Mac II ROMs through their
memory tests, and System 6 and System 7.5 to the Finder from a floppy
image, a hard disk volume or a SCSI hard disk, where the mouse and keyboard
work.
See [docs/ROADMAP.md](docs/ROADMAP.md).

## Quick start

1. **Get a ROM.** The ROM picks the Mac: the 128K's and 512K's 64 KB ROM
   (`28BA61CE` or `28BA4E50`; pick the 128K or 512K), a 128 KB Macintosh
   Plus ROM (v1, v2 or v3, which runs as a Plus or a 512Ke), a 256 KB SE or SE FDHD ROM, the Classic's 512 KB ROM, or a
   256 KB Macintosh II ROM (`97851DB6` or `9779D2C4`, or `97221136` from
   the II FDHD, IIx, IIcx and SE/30, which runs as a II FDHD unless you
   pick one of the others);
   Chime68 tells them apart by the checksum in their first four bytes and
   names the one it finds. ROMs are Apple's copyright and aren't included:
   dump the one in your own Mac, or use a dump you are entitled to.
2. **Get a disk.** Any of these work:
   - a 400K or 800K floppy image, raw (`.dsk`, `.img`) or DiskCopy 4.2
     (System 6 install and Tools disks, for instance); on the SE FDHD and
     Classic, also 720K and 1.44 MB MFM floppies;
   - a hard disk image partitioned by an Apple formatter (it starts with the
     `ER` signature), with its own driver;
   - a bare HFS volume of any size, as Mini vMac uses (`disk1.dsk` and the
     like). Chime68 serves it through its own driver.

   A file of zeros (`mkfile -n 40m blank.img` on macOS, or
   `truncate -s 40M blank.img`) attached with `--scsi` appears in the
   Finder as a disk to initialize. So does a blank floppy: 800K of zeros
   (`mkfile -n 800k blank.dsk`) on every model, or 1440K (`mkfile -n
   1440k blank.img`) on the SE FDHD and Classic. The Finder formats it,
   and what is copied to it is saved to the file.
3. **Run it.** Download a binary from the
   [releases page](https://github.com/pepito2k/chime68/releases), or build
   one (below), then:

   ```sh
   chime68 --rom MacPlus.rom --scsi System608.dsk
   ```

   The startup chime plays, the memory test runs fast, and the Finder comes
   up in a few seconds. Drag more disk images onto the window to mount them.

   Or run `chime68` with no arguments (or double-click it) for the setup
   window: choose the ROM (which picks the Mac), memory, a floppy and SCSI
   disks (or drop the files on the window), speed, sound and what the serial
   ports are plugged into, then Start. Quitting the Mac (Command-Control-Q) comes back
   to it, and it remembers the last setup (in `Chime68/machine.cfg` in your
   configuration folder; Application Support on a Mac).

   The setup window's Configuration menu saves a setup under a name (Save
   Configuration As...), lists the saved ones and the last few started, and
   on a Mac puts one on the desktop (Put on Desktop): an icon that starts
   that Mac when double-clicked. `chime68 --profile NAME` starts a saved one
   from the command line (or `--profile FILE.chime68`, for one saved
   elsewhere); other options given with it change it for that run.

   Drop a StuffIt archive (`.sit`), a BinHex (`.hqx`) or MacBinary file or a
   DiskCopy 6 image on the window (or give it as a disk) and Chime68
   unpacks it to a plain disk image beside it (`NAME.dsk`) and mounts that:
   the disk an archive holds, or a new disk with its files on it.

   With `--snapshot` (Disk writes: Snapshot in the setup window) the disk
   images are left as they are: what the Mac writes goes to
   `IMAGE.snapshot` beside each one, kept from run to run until Disk
   Options › Commit Snapshot writes it to the images or Discard Snapshot
   and Restart throws it away. `--read-only` keeps the writes in memory
   only.

   Along the way, Disk Options keeps a history of named snapshots. Take
   Snapshot... names one and keeps the disks as they are then (in
   `IMAGE.snapshots/` beside each image). Roll Back to Snapshot... puts
   them back as they were in one and restarts the Mac, losing what was
   written since the last snapshot; Branch from Snapshot... does the same
   but first keeps where the disks were as a snapshot of its own ("Left
   from ..."), so you can try something from an older point and still come
   back. Snapshot History... shows them as a tree, each under the one it
   came from, and which one the disks come from now. Committing keeps them
   all good: each gets the image's old blocks where the commit changes it.
   A snapshot taken while the Mac runs is like a disk after a power cut, so
   System 7.5 may say at the next startup that it wasn't shut down
   properly (press Return). The control socket has `snapshot list`, `take`,
   `rollback`, `branch` and `delete`.

   The Window menu scales the screen by a whole number (sharp pixels, the
   default) or to fill the window, keeping its shape or not, and has a CRT
   Look (scanlines, a slightly curved face, phosphor glow). F6 (Save
   Screenshot) puts a PNG of the Mac's screen on your desktop. Show Disk
   Activity (on unless you turn it off) puts a light in the window's title
   bar (on a Mac, a small rectangle at the right, like the one on Apple's
   old hard disks), dark while the disks are idle, that turns green while
   a floppy, hard disk or CD-ROM is read and amber while one is written, and badges the Dock icon while the
   window is minimized or covered; screenshots and recordings leave it out.

   On a Mac, the releases page also has **Chime68.app**: unzip it, put it
   in Applications and double-click it for the setup window. Drop disk
   images, a ROM or a folder on its icon (in the Finder or the Dock) or on
   its window to use them. Release builds are signed with a Developer ID
   and notarized by Apple, the app and the command-line `chime68` both, so
   they open like any other download. A build that isn't (one you made
   yourself, or from a fork) is signed ad hoc, and macOS 15 won't open it
   from a double-click or Control-click Open: try to open it once, then in
   System Settings, Privacy & Security, click Open Anyway next to the note
   about Chime68 and confirm (or run `xattr -d com.apple.quarantine` on
   it). If your ROMs and disks are on the Desktop or in Documents, macOS
   asks once whether Chime68 may read them.

   Keep your ROMs in one folder (`roms` on the desktop, unless you pick
   another) and the setup window's Macs... button lists every Mac Chime68
   runs, the ones with a ROM in that folder ready to click: pick a Mac by
   name rather than its ROM file. The list looks through the folder the
   first time it opens, takes ROMs Chime68 knows by their checksum (one
   ROM can serve several Macs), and its Folder... button picks another
   folder, which the setup remembers.

## Building

```sh
cargo build --release      # the binary is target/release/chime68
cargo run --release -- --rom MacPlus.rom --scsi System608.dsk
```

`scripts/bundle-macos.sh target/release/chime68` wraps the binary in
`Chime68.app` (its icon is drawn by `scripts/make-icon.py`).

On Linux, building needs the ALSA headers (`libasound2-dev` on Debian and
Ubuntu); `--no-default-features --features window` builds without sound,
and `--no-default-features` builds a headless binary with no window either.

## The Macintosh II

A Mac II ROM gives a Macintosh II: a 68020 with its 68881 maths
coprocessor, 8 MB of RAM (`--ram` 1, 2, 4 or 5 for less), the Apple Sound
Chip for the startup chime and the Sound Manager, ADB, SCSI, the SCC and
the floppy drive (a SuperDrive with the II FDHD ROM). It has no video of its
own: Chime68 puts a video card of its own in NuBus slot 9 (with its own
declaration ROM and driver), which drives a 640×480 monitor in black and
white, 4, 16 or 256 colours or grays; pick them with the Monitors control
panel. The window opens at that size. It has a 68851 PMMU in the socket
Apple's own address translation otherwise takes, so System 7's virtual
memory works (turn it on in the Memory control panel and restart), as does
32-bit addressing. The 68881 computes in its full 80-bit extended precision.

```sh
chime68 --rom "9779D2C4 - MacII.ROM" --scsi System7.dsk
```

## The 128K, 512K and 512Ke

The **Macintosh 128K** and **512K** are a Plus without SCSI, with 128 or
512 KB of RAM and a 64 KB ROM that reads only 400K MFS floppies: boot
them from a System 1 to 3 disk (`--model 128k` or `512k` picks one; the
ROM runs in both). The **512Ke** is a 512K with the Plus's ROM and an
800K drive (`--model 512ke` with a Plus ROM).

```sh
chime68 --rom "28BA4E50 - Macintosh 512K.ROM" --disk System3.2.dsk
```

## The IIx, IIcx, SE/30, IIci and IIsi

These have a 68030, whose MMU their ROMs use to map the 24-bit address
space (and which System 7's virtual memory pages through), with the 68882.

The **SE/30** is a IIx in a compact case. It shares its ROM (checksum
`97221136`) with the II FDHD, IIx and IIcx, so the ROM alone can't say
which it is: give `--model se30` (or `iix`, `iicx`), or click the Machine
pop-up in the setup window to switch between the II FDHD, IIx, IIcx and
SE/30. The **IIx** is a Mac II with a 68030 and a SuperDrive, and the
**IIcx** the same machine in a smaller case with three NuBus slots; both
run at 16 MHz with 1 to 32 MB and a Chime68 video card, as the II does. Its 512×342 screen is
the compact Mac's, in black and white; Chime68 stands in for the board's
video ROM with one of its own. It takes 1 to 128 MB; past 8 MB the System
needs 32-bit addressing, which its ROM leaves to MODE32 or Apple's 32-bit
System Enabler.

The **IIci** (ROM checksum `368CADFE`) runs at 25 MHz with 4 to 128 MB,
and its built-in video shows a 13" colour monitor (640×480, up to 256
colours) from the start of RAM. Its ROM is 32-bit clean: turn on 32-bit
addressing in the Memory control panel to use more than 8 MB.

On the SE/30 and IIci, virtual memory works: turn it on in the Memory
control panel and restart. With 64 or 128 MB the power-on memory test
takes a while (about 12 s at full speed for 128 MB, with the fast memory
test on).

```sh
chime68 --rom "97221136 - Mac II FDHD & IIx & IIcx.ROM" --model se30 --scsi System7.dsk
chime68 --rom "368CADFE - Mac IIci.ROM" --scsi System7.dsk
```

Both boot System 6.0.8 and 7.5.5 to the Finder, and the IIci Mac OS 7.6.1
too (Mac OS 8 needs a 68040). Mac OS 7.6 requires 32-bit addressing, so
on the SE/30 (and the Mac II) it stops at startup unless MODE32 is
installed. Headless, from power on
through the boot to the Finder (`--frames 4000`, about 66 s of the Mac's
time), on an Apple silicon Mac: the SE/30 runs at 17 times its real
speed, the IIci at 11 times (and the Mac II at 21, the Plus at 59). The
IIci runs about five times as many instructions a second as a Plus, so
it is as fast for Chime68 per instruction; it just has more of them.

The **IIsi** (ROM checksum `36B7FB6C`) is a IIci at 20 MHz with no FPU
and no NuBus slots, and 1 to 17 MB; the same built-in video shows the same
monitors. Its Egret chip keeps the clock and PRAM, runs ADB, and switches
the Mac off at Shut Down.

```sh
chime68 --rom "36B7FB6C - Mac IIsi.ROM" --scsi System7.dsk
```

## The IIfx

The **IIfx** (ROM checksum `4147DD77`) is a Mac II at 40 MHz with 4 to 32
MB and Chime68's video card (the II's monitors). Its SCC and floppy drive
are behind I/O processors, with ADB on the floppy's, as on the Quadra 900;
an OSS chip takes interrupts in VIA2's place and switches it off at Shut
Down, and its SCSI DMA chip moves the disk's data.

```sh
chime68 --rom "4147DD77 - Mac IIfx.ROM" --scsi System7.dsk
```

## The IIvx and IIvi

The **IIvx** and **IIvi** share a ROM (checksum `4957EB49`, also the
Performa 600's), so it starts a IIvx unless you pick the IIvi
(`--model iivi`): 32 MHz with a 68882, or 16 MHz without an FPU, both with
4 to 68 MB and three NuBus slots. Their built-in video (VASP) has 512K of
its own and shows a 13" or 12" RGB monitor in up to 256 colours; Egret
keeps the clock, runs ADB and switches the Mac off at Shut Down.

```sh
chime68 --rom "4957EB49 - Mac IIvx & IIvi.ROM" --scsi System7.dsk
```

## The LC and LC II

The **LC** (ROM checksum `350EACF0`, a 68020) and **LC II** (`35C28F5F`,
a 68030) are 16 MHz Macs built around V8, which decodes only 24 address
bits: 4 to 10 MB (4 to 8 on the LC II), Egret for the clock, the PRAM and
ADB, and built-in video with 512K of its own, up to 256 colours on a 13"
or 12" RGB monitor. They have no soft power switch: Shut Down ends at "It
is now safe to switch off your Macintosh".

The **Classic II** (`3193670E`) is the same machine in a compact case:
a 16 MHz 68030 with 4 to 10 MB, and the compact Macs' 512×342 screen in
black and white. Shut Down switches it off.

The **Color Classic** (`ECD99DC0`) is it again with a 512×384 colour
screen, up to thousands of colours, and Cuda, Egret's successor: 4, 6, 8
or 10 MB, and Shut Down switches it off.

```sh
chime68 --rom "350EACF0 - Mac LC.ROM" --scsi System7.dsk
chime68 --rom "3193670E - Classic II.ROM" --scsi System7.dsk
chime68 --rom "ECD99DC0 - Color Classic.ROM" --scsi System7.dsk
```

## The LC III

The **LC III** (ROM checksum `ECBBC41C`, or the older `EC904829`) is a
25 MHz 68030 without an FPU, built around Sonora: 4 MB on the board and a
SIMM (4, 5, 6, 8, 12, 20 or 36 MB in all), Egret, and video with its own
RAM, up to thousands of colours on a 13" or 12" RGB monitor, or grays on
the 15" Portrait. Its sound is the Quadras' Enhanced ASC. Like the LC, it
has no soft power switch.

```sh
chime68 --rom "ECBBC41C - Mac LC III.ROM" --scsi System7.dsk
```

## The Quadra 700

The **Quadra 700** (ROM checksum `420DBFF3`, the Quadra 700 and 900's)
is a 68040 at 25 MHz, with the 68040's own MMU and FPU, 4 MB on the board
plus SIMMs (4, 8, 20, 36 or 68 MB in all), DAFB video with its own VRAM
showing a 13" colour monitor (640×480, up to 256 colours), and an NCR 53C96
SCSI controller. It needs System 7 (7.1 or later; 7.5.5 boots to the
Finder, with virtual memory and 32-bit addressing), and runs Mac OS 7.6.1,
8.0 and 8.1: their install CDs start it up, and their installers install
onto a hard disk image.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --scsi System7.dsk
```

Its sound is the Quadras' Enhanced ASC: no wavetable, its two FIFOs
played at 44.1 kHz through its sample rate converters (and CD-XA ADPCM,
if asked), so the startup chime and the alert sounds of System 7.5.3, Mac
OS 7.6.1 and 8.1 play on the Quadra 700, 900 and 950.

The same ROM is the **Quadra 900**'s: `--model q900` (or the setup
window's Machine pop-up) runs it as one, and the **Quadra 950** runs its
own ROM (checksum `3DC27823`), at 33 MHz. They are Quadra 700s with
Egret, Apple's system controller, keeping the clock and the PRAM and
switching the power off; the SCC and the SWIM behind I/O processors, two
65C02s that run the code the ROM and the System give them (Chime68
emulates the 65C02, so ADB, which the SWIM's I/O processor drives bit by
bit, the floppy drive and the serial ports work through Apple's own
firmware); and a second 53C96 for an external SCSI bus, which Chime68
leaves empty. They take 4, 8, 16, 32, 64, 80, 96, 128, 192 or 256 MB, as
their four banks of SIMMs did.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --model q900 --scsi System7.dsk
chime68 --rom "3DC27823 - Quadra 950.ROM" --scsi System7.dsk
```

## The Quadra 605 and LC 475

The **Quadra 605** (ROM checksum `FF7439EE`) is a cut-down Quadra: a
25 MHz 68040 with 4 MB on the board plus a SIMM (4, 8, 12, 20 or 36 MB in
all), DAFB video inside its memory controller (the same monitors as the
Quadra 700's), a 53C96, Cuda and the Enhanced ASC, without NuBus. The
**LC 475** runs the same ROM with a 68LC040, without an FPU: `--model
lc475`, or the setup window's Machine pop-up.

```sh
chime68 --rom "FF7439EE - Quadra 605.ROM" --scsi System7.dsk
chime68 --rom "FF7439EE - Quadra 605.ROM" --model lc475 --scsi System7.dsk
```

## The Quadra 800, 650 and 610 and the Centris 650 and 610

One ROM (checksum `F1ACAD13`, or the older `F1A6F343`) runs all five; it
starts a **Quadra 800** (33 MHz), and `--model q650`, `q610`, `c650` or
`c610` (or the setup window's Machine pop-up) picks the others: the
**Quadra 650** (33 MHz) and **610** (25 MHz), and the **Centris 650**
(25 MHz) and **610** (20 MHz), whose 68LC040s have no FPU. They have 8 MB
on the board (4 on the 610s) plus SIMMs, up to 136 MB, the Quadra 700's
monitors, a 53C96, Ethernet and the Enhanced ASC, and Shut Down switches
them off.

```sh
chime68 --rom "F1ACAD13 - Quadra 800.ROM" --scsi System7.dsk
chime68 --rom "F1ACAD13 - Quadra 800.ROM" --model c610 --scsi System7.dsk
```

## The Quadra and LC 630 and the LC 580

The **Quadra 630** (ROM checksum `06684214`) is a 33 MHz 68040 with 4 MB
on the board plus a SIMM (4, 8, 12, 20 or 36 MB in all), Valkyrie video
(up to thousands of colours on a 13" or 12" RGB monitor), Cuda, a SCSI bus
for external disks and CDs, and an internal IDE disk: `--ide <image>`
fits one, which it writes back as it does SCSI disks. The **LC 630** runs
the same ROM without an FPU (`--model lc630`), and the **LC 580** runs its
own (`064DC91D`).

```sh
chime68 --rom "06684214 - Quadra 630.ROM" --ide MacOS761.img
chime68 --rom "06684214 - Quadra 630.ROM" --model lc630 --scsi System7.dsk
```

## The Quadra 840AV and 660AV

The **Quadra 840AV** (ROM checksum `5BF10FD1`, a 2 MB ROM; 40 MHz) and
**660AV** (`--model q660av`; 25 MHz) have their own chips: a 53C94 SCSI
controller moving its data by DMA, Cuda, and Civic video up to millions of
colours on a 13" monitor, with 8 to 128 MB, and their built-in Ethernet
(the MACE chip, fed by the PSC's DMA). System 7.5.3 boots to the Finder,
and the startup chime plays. The System's own sounds, the alert sounds
and the Sound control panel's, go through the AVs' DSP3210, a signal
processor that runs the Sound Manager's code alongside the 68040; Chime68
runs it too. There's no floppy drive on them yet (their New Age floppy
controller isn't emulated, in MAME either).

```sh
chime68 --rom "5BF10FD1 - Quadra 840AV.ROM" --scsi System7.dsk
```

Their video input is the host's camera: the AVs' video digitizer (in their
ROM) drives its decoder and scaler on Cuda's IIC bus and Civic digitizes
the picture into its video RAM, where the screen shows it through the key
colour the digitizer paints its window with (so windows in front hide it),
and QuickTime grabs copy it from. Apple Video Player (from the TV/FM
software on the Mac OS 7.6 CD, with its Video Startup and Video Digitizer
Update extensions) shows it live and copies frames; the AVs' own Video
Monitor and any QuickTime capture use the same digitizer. The camera only
runs while the Mac is digitizing (macOS asks once whether Chime68 may use
it). `--video-in PICTURE` shows a still picture instead (it works headless
too), and `--no-camera` leaves the input dark.

## Bigger screens and a second monitor

`--monitor WxH` (or Monitor in the setup window) plugs in another monitor
where the Mac drives more than one:

| Mac | Monitors |
|---|---|
| Mac II, II FDHD, IIx, IIcx, IIfx | 640×480, 832×624, 1024×768 and 1152×870 (Apple's 13", 16", 19" and 21"), on Chime68's video card, 1 to 8 bits per pixel |
| Quadra 700 | 640×480 (13" RGB), 832×624 (16" RGB), 640×870 (15" Portrait) and 1152×870 (21" RGB): DAFB finds the monitor on its sense lines and its ROM sets the mode up, as on the real machine, which has no 19" mode |
| IIci, IIsi, LC III | 640×480 (13" RGB), 512×384 (12" RGB) and 640×870 (15" Portrait) |
| IIvx, IIvi, LC, LC II | 640×480 (13" RGB) and 512×384 (12" RGB) |

The Monitors control panel then picks the depth (and the Portrait shows
grays, as the real one did). The monitor is fixed while the Mac runs, as
plugging one in was: choose it before starting.

`--second-monitor WxH` (or Second in the setup window) adds a second
monitor, on a Chime68 video card of its own (in slot $A on the Mac II,
IIx, IIcx and IIfx, $D on the IIci, IIvx and Quadra 700, and on a Duo, $C,
the first slot of the Duo Dock it's then in), shown in a second window. The system puts it to the right of the main screen; drag
it about in the Monitors control panel, and the mouse goes across both
windows the same way.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --scsi System7.dsk --monitor 1152x870 --second-monitor 832x624
```

`--cache-card` (or Cache card in the setup window) puts Apple's 32K cache
card in a IIci's cache connector, which makes it about a fifth faster
while the system has it on (the ROM switches it on as it starts up).

Windows open at twice the Mac's size when that fits on the host's display,
smaller otherwise.

## The PowerBook 140 and 170

The same ROM is the **PowerBook 140**'s and **170**'s: `--model pb140` or
`--model pb170` (or the setup window's Machine pop-up) runs it as one. Both
are a 68030 with a 640×400 black-and-white LCD; the 140 at 16 MHz with no
FPU, the 170 at 25 MHz with a 68882. They take 2, 4, 6 or 8 MB (the 170
from 4); Chime68 gives them 4 and 8 unless `--ram` says otherwise, as
System 7.5 wants more than the 140's 2 MB on the board. They need System 7
(7.5.3 boots to the Finder).

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --model pb170 --scsi System7.dsk
```

The keyboard and trackball are the Mac's keyboard and mouse, through the
power manager, which Chime68 does at the level of its commands (its own
firmware isn't needed). Idle, it turns its processor off between
interrupts, as the real ones do to save power.

Sleep (the Special menu's, or the system's own when the battery runs out)
darkens the screen and stops the Mac where it is; a key or the trackball's
button wakes it, and it carries on from there. Shut Down switches it off
and quits Chime68, saving the disks and PRAM.

The battery takes two hours to run down off the power adapter and two to
charge back on it. The adapter is plugged in unless `--battery PERCENT`
starts the PowerBook off it with that much charge; Power Adapter in the
Machine menu plugs it in and pulls it out. Running low, the system warns
that little reserve power remains, and then puts the PowerBook to sleep
until the adapter's back.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --model pb140 --scsi System7.dsk --battery 15
```

### The PowerBook 160 and 180

The **PowerBook 160** has a ROM of its own, which is also the **180**'s:
`--model pb180` (or the Machine pop-up) runs it as a 180. Both are the
140's machine with a faster 68030 (25 MHz in the 160, 33 with a 68882 in
the 180), Niagra in Jaws's place, and a 640x400 LCD in black and white, 4
or 16 grays (Monitors picks), on the GSC, Apple's grayscale controller.
They take 4, 6, 8, 12 or 14 MB (8 unless `--ram` says otherwise), boot
System 7.5.3 to the Finder, and sleep, wake and run on the battery as the
140 and 170 do. The external monitor port reads as having nothing plugged
in.

```sh
chime68 --rom "E33B2724 - Powerbook 160 & 165c & 180 & 180c.ROM" --model pb180 --scsi System7.dsk
```

The same ROM runs the **PowerBook 165c** and **180c** (`--model pb165c` or
`pb180c`): the 180 with a colour LCD, 640x400 on the 165c and 640x480 on
the 180c, in up to 256 colours (Monitors picks). Apple drove it from a VGA
chip with a declaration ROM of its own on the board, in slot $C; Chime68's
video card stands in for both there, as it does for the SE/30's video.
The ROM tells them from the grayscale models by the GSC that isn't there,
and takes them for a 180 otherwise; Apple's video ROM told the two apart,
and Chime68's card does the same once the System starts, so Gestalt says
PowerBook 165c or 180c. They sleep and wake as the 180 does.

```sh
chime68 --rom "E33B2724 - Powerbook 160 & 165c & 180 & 180c.ROM" --model pb180c --scsi System7.dsk
```

### The PowerBook Duo 210, 230 and 250

The **Duo 210**'s ROM is also the **230**'s and **250**'s (`--model duo230`
or `duo250`, or the Machine pop-up): a 68030 at 25 or 33 MHz (the 250 with
an FPU) around the MSC, Apple's system controller for the Duos, with the
GSC's 640x400 LCD in up to 16 grays. Its power manager, the PG&E, takes
its firmware from the ROM at startup and its commands through VIA1's
shift register; Chime68 does it at the level of those commands, as it
does the 140's. They take 4, 8, 12, 16 or 24 MB (8 unless `--ram` says
otherwise), boot System 7.5.3 to the Finder with the keyboard and
trackball, sleep and wake, and switch off at Shut Down. The battery runs
down off the adapter and charges on it, as the 140's does, with its level,
the charging bolt and the low-power warnings in the menu bar.

`--second-monitor WxH` (or Second in the setup window) puts the Duo in a
Duo Dock with a monitor on it: Chime68's video card in the dock's first
NuBus slot, in a second window beside the Duo's screen, and the dock's
floppy drive, a SuperDrive on a SWIM II, for 1.44 MB, 720K and 800K
floppies. Docked, the Duo doesn't sleep ("cannot Sleep when connected to
this type of dock"), as with Apple's dock.

```sh
chime68 --rom "ECFA989B - Powerbook 210,230,250.ROM" --model duo230 --scsi System7.dsk
```

### The PowerBook Duo 270c, 280 and 280c

The **Duo 270c** has a ROM of its own (`0024D346`), and the **280** and
**280c** share one (`015621D7`; `--model duo280c`, or the Machine pop-up):
the Duo 210's machine with the CSC, Apple's colour screen controller, in
the GSC's place. The 270c is a 68030 at 33 MHz with an FPU and a 640×480
active-matrix colour LCD in up to 256 colours; the 280 and 280c a 68040 at
33 MHz (the 280's a 68LC040, without the FPU), the 280 with a 640×400 LCD
in 16 grays, the 280c with the 270c's colour one. Monitors switches the
depth. The rest is the Duo 210's: the battery, sleep and wake, Shut Down,
and the Duo Dock's monitor (`--second-monitor`). The 270c takes 4 to 32 MB (8 unless `--ram` says otherwise),
the 280 and 280c 4 to 40 (12).

```sh
chime68 --rom "015621D7 - Powerbook 280&280c.ROM" --model duo280c --scsi System7.dsk
```

### The PowerBook 150

The **PowerBook 150** (ROM `FDA22562`) is a Duo 230 inside: a 68030 at 33
MHz without an FPU, the MSC and the PG&E, and the GSC driving a 640×480
LCD in 16 grays, with an IDE hard disk inside (`--ide`, or the setup
window's IDE disk, wired as the Quadra 630's) and SCSI for external disks.
It takes 4 to 40 MB (8 unless `--ram` says otherwise), boots System 7.5.3
from SCSI and Mac OS 7.6.1 from its IDE disk, with the battery, sleep and
Shut Down of the Duos.

```sh
chime68 --rom "FDA22562 - Powerbook 150.ROM" --ide HD.img
```

### The PowerBook 540c

The **PowerBook 540c** (ROM `B6909089`, 2 MB, which the 520 and 540 share)
is a 68LC040 at 33 MHz built from Quadra and PowerBook parts: VIA1 and a
real VIA2, the SCC, the Enhanced Apple Sound Chip and the SONIC's
Ethernet as on a Quadra, the 5380 and the SWIM as on the PowerBook 140,
the Duos' CSC driving a 640×480 colour LCD in up to 256 colours, and the
PG&E, here with its handshake on VIA2's port B and smart batteries. It
takes 4 to 36 MB (8 unless `--ram` says otherwise), plays the startup
chime and boots System 7.5.3 and Mac OS 7.6.1 to the Finder with its
battery in the menu bar, and Shut Down switches it off. Not yet: the 520
and 540's grayscale LCDs, and the chips the ROM pokes at `$50080000` and
in slot $E's space, which do nothing here.

```sh
chime68 --rom "B6909089 - PowerBook 520 520c 540 540c.ROM" --scsi System7.dsk
```

### The PowerBook 100

The **PowerBook 100** is the Macintosh Portable's machine in a smaller
case: a 68000 at 15.67 MHz with the SWIM and an external floppy drive, the
Apple Sound Chip, one VIA and a 640x400 LCD in black and white. Its power
manager takes its commands in parallel on the VIA's port A; Chime68 does
it at the level of those commands, as it does the 140's. It takes 2, 4, 6
or 8 MB (4 unless `--ram` says otherwise), boots System 7.5.3 to the
Finder with the keyboard and trackball, reads floppies, runs down its
battery and sleeps and wakes as the 140 does. Shut Down switches it off
and quits Chime68, as on the 140.

```sh
chime68 --rom "96645F9C - PowerBook 100.ROM" --scsi System7.dsk
```

### The Macintosh Portable

The **Macintosh Portable** (ROM checksum `96CA3846`) is the same machine,
with its own ROM and 1 to 9 MB (2 unless `--ram` says otherwise; System
7.5 needs 2). It boots System 7.5.3 to the Finder, with the keyboard and
trackball, and Shut Down switches it off.

```sh
chime68 --rom "96CA3846 - Mac Portable.ROM" --scsi System7.dsk
```

## A/UX

Apple's Unix, A/UX 3.0, runs on the IIci, the SE/30 and the Quadra 700. Its
install CD is a whole A/UX system that runs from the disc: made into a hard
disk, it starts up the Mac side, and A/UX Startup on it starts A/UX from the
CD's own Unix partitions, to the login window, the A/UX Finder and
CommandShell.

The CD lists no driver in its driver descriptor map and has no boot blocks,
since Apple meant it to be started from a floppy. `chime68 disk bootable`
puts both in a copy of it, the boot blocks from a System 7 disk of yours:

```sh
cp "Apple AUX 3.0.iso" aux.img
chime68 disk bootable aux.img --boot-blocks-from System7.img
chime68 --rom MacIIci.rom --ram 16 --scsi aux.img
```

Double-click A/UX Startup on the "A/UX CDInstall" disk, and log in as
`root` (no password) when A/UX asks. A/UX needs 8 MB or more and the
68030's or 68040's MMU (on the Quadra 700, 20 MB is a good size); it takes
the mouse and keyboard as the Mac's, and Shut Down in its Special menu
switches the IIci off, which quits Chime68. Restart goes back to the Mac
OS on the CD.

### Installing A/UX on a hard disk

The CD's system is a small one, with the install files beside it. To have
all of A/UX on a disk of its own, install it from the CD onto a blank disk
image of 500 MB or more, after the CD on the bus:

```sh
mkfile -n 500m aux-hd.img        # or truncate -s 500m aux-hd.img
chime68 --rom Quadra700.rom --ram 20 --scsi aux.img --scsi aux-hd.img
```

1. Cancel the Mac OS's offer to initialize the blank disk.
2. Open the CD, double-click A/UX Startup and press Command-period while
   its copyright notice shows: that stops it at its `startup#` prompt.
3. Type `launch -e (0,0,6)/unix`. This starts A/UX from the CD's
   installer partition (slice 6) instead of its root, and A/UX runs the
   A/UX Installer in place of the login window.
4. In the A/UX Easy Install window, click Switch Disk until it names SCSI
   device 1, the blank disk, then Install, and OK when it warns that the
   disk will be erased. It partitions the disk (a small Mac partition with
   A/UX Startup, swap, the Unix root and a free Unix partition) and copies
   A/UX onto it, about twelve minutes of the Mac's time.
5. Click Restart when it's done, quit Chime68, and start the new disk on
   its own: `chime68 --rom Quadra700.rom --ram 20 --scsi aux-hd.img`. Its
   Mac partition (MacPartition) starts up; A/UX Startup on it starts A/UX
   from the disk, where it's writable like any other system.

A blank image the Mac partitions itself becomes a whole disk in its file
(Chime68 serves a file of zeros as a bare volume until then), so the file
grows by 32K.

## Disks

| Flag            | Puts the image                                                  |
|-----------------|-----------------------------------------------------------------|
| `--disk IMAGE`  | A floppy image in the internal drive (a second `--disk`, in the second drive); a partitioned disk on the SCSI bus; a bare volume on the built-in disk driver (no floppy drive then) |
| `--scsi IMAGE`  | On the SCSI bus, at IDs 0, 1, 2... in order (up to 6). Bare volumes get Chime68's SCSI driver and a partition map in front of them, in memory only |
| `--folder DIR`  | A host folder as a volume on the SCSI bus, after the `--scsi` disks (see below) |
| `--cd IMAGE`    | A CD image (ISO, Toast, `.cdr`, or a `.cue` sheet with its BIN files) in a CD-ROM drive on the SCSI bus, after the disks and the folder (see below) |
| `--read-only`   | Keeps the Mac's writes in memory and leaves the files alone      |

`--scsi` is the most faithful way to run a hard disk (the ROM's own SCSI
code boots it) and keeps the floppy drive available; prefer it to `--disk`
for hard disks. With several System disks, System 6 starts up from ID 0.

Before it starts, Chime68 looks at the System on each hard disk and floppy
image. If every System it finds is newer than the Mac runs, it stops with
an alert instead of letting the Mac stop at a Sad Mac: Mac OS 7.6 and
later on the 68000s (the Plus, SE, Classic, Portable and PowerBook 100),
Mac OS 8 on the 68020s and 68030s, and System 7 on the 512Ke.

What the Mac writes is saved to the image files: hard disks after every
frame, block by block, and floppies as a whole file once the Mac stops
writing for half a second, and on quit. Quit with Command-Control-Q or the
window's close button, rather than Ctrl-C, so the last floppy writes are
saved. Choose Shut Down on the Mac first: quitting while the Mac runs is
switching it off, and System 7.5 and later then warn on the next start that
it wasn't shut down properly.

Every Mac has two floppy drives: the internal one (drive 1) and a second
one (drive 2), which is the external drive, or on the Mac II and IIx the
second internal one. While the Mac runs, drop an image on the window to
mount it: a floppy goes in the first empty drive (or, with both full, in
drive 1 in place of the disk there, which is saved first), anything else on
the SCSI bus at the next free ID. A hard disk with an HFS volume (a bare
volume, or the HFS partition of a partitioned disk) mounts at once: the ROM
only looks for SCSI disks at startup, so Chime68 has the Mac load its own
SCSI driver for the new disk into the system heap, which mounts it as the
ROM's loader would have. Other disks show after the next restart.
Eject floppies from the Finder (Command-E or drag to the Trash) when you can;
F8 pulls drive 1's disk out like a paperclip in the eject hole, and
Shift-F8 drive 2's.

### Looking inside a disk image

Disk Options › Browse Disk Image opens a disk image without starting a
Mac: its files and folders in a window of their own (a bare HFS volume,
the HFS partition of a partitioned disk, or a DiskCopy 4.2 floppy).
Double-click a folder to open it and Up to go back; Save as MacBinary
copies the selected file out, both forks and its type and creator in one
`.bin` file. Add Files (or dropping files and folders on the window) copies
host files in, into the folder shown, and saves the image: a MacBinary or
BinHex file goes in as the file it holds, and others with the type and
creator the host keeps for them, or from their extension. A disk the Mac
has mounted can be looked at but not added to. The same from a shell:

```sh
chime68 disk ls System7.img "System Folder"
chime68 disk get System7.img "System Folder:Finder"         # Finder.bin, MacBinary
chime68 disk put System7.img Stuff.sit notes.txt --to Documents
```

Files go into the volume in place, so the disk still starts up; its
catalog is laid out again around them. MFS and HFS+ disks can't be
browsed.

### Finding software online

Software › Find Software Online opens a window that searches the
[Macintosh Garden](https://macintoshgarden.org) and the
[Internet Archive](https://archive.org)'s Mac software at once. Type a
name and press Return; double-click a title (or Show Files) for the disk
images and archives it has, and double-click one of those (or Download and
Mount) to fetch it and give it to the Mac. StuffIt, BinHex, MacBinary and
zip archives become a disk next to the download, as when they're dropped on
the window (see [Disks](#disks)); a CD image goes in the CD-ROM drive, a
`.cue` sheet with its tracks, and a zip holding a cue sheet is unpacked
into a folder beside it first. Downloads go to `~/Desktop/roms/garden` if
there's a `roms` folder on the desktop, else to `~/Downloads/Chime68`
(Change... picks another folder); a file already there at the same size
isn't fetched again. The same from a shell:

```sh
chime68 software search marathon
chime68 software files https://macintoshgarden.org/games/marathon
chime68 software get marathon-demo MarathonDemo.img ~/Desktop/roms/garden
```

### Copying files and text

A file dropped on the window that isn't a disk image (a document, a
StuffIt archive, an application) is copied onto the Mac's desktop, by the
Mac itself: Chime68 waits until an application asks the Mac for its next
event, then has the File Manager create and write the file there, so it
shows up in the Finder at once. A name already taken gets a number on the
end. The type, creator and resource fork come along as for a shared folder
(below): from the host file's own on macOS, an AppleDouble `._name` file
elsewhere, or the extension.

Text and pictures go between the clipboards the same way: what you copy
on the Mac is on the host's clipboard to paste, and what you copy on the
host is on the Mac's when you come back to Chime68's window. Mac Roman and
line ends are converted both ways. An image copied on the host becomes a
QuickDraw picture (a PICT), in 256 colours on a Mac with Color QuickDraw
and dithered to black and white on one without, shrunk to 1024 pixels if
it's bigger. A picture copied on the Mac (from the Scrapbook, MacPaint,
MacDraw, anything) is drawn by the Mac's own QuickDraw, so every kind of
picture comes out as it looks there, and lands on the host's clipboard as
an image; when the Mac copies text with it, the text goes instead.
`--no-clipboard` (or Clipboard in the setup window) keeps them apart. Most
applications paste the new text at once; one that keeps a clipboard of
its own (TextEdit's, in some old programs) sees it after you switch to
another application and back.

### CDs

`--cd game.iso` (or CD-ROM in the setup window, or a CD image dropped on
the window) puts the disc in a CD-ROM drive that tells the Mac it is an
AppleCD 300, so Apple's CD-ROM software takes it as one of Apple's own:

- A bootable Apple CD (a System 7.5, Mac OS 7.6 or Mac OS 8 install disc,
  say) starts the Mac up: Chime68 serves its HFS partition behind its own
  driver, which every one of them boots with (the newer discs' own drivers
  don't take the drive at startup here). Run its installer onto a hard
  disk and the Apple CD-ROM extension, Foreign File Access and ISO 9660
  File Access come with it; from then on Apple's extension runs the drive
  and sees the whole disc.
- A disc that is a bare HFS volume, as most CD images from the period's
  archives are, also mounts on a System without Apple's CD-ROM software:
  Chime68 puts its own driver in front of it, and the disc mounts locked.
  Where Apple's extension is installed, it takes the drive over instead.
  (System 6's Finder opens only discs that carry its Desktop file.)
- An ISO 9660 disc needs Foreign File Access and ISO 9660 File Access.

- A BIN/CUE image (`--cd game.cue`, the cue sheet with its BIN files next
  to it) brings the disc's audio tracks too: the drive answers the Mac's
  audio commands (play from an address, an MSF time or a track, pause,
  stop, the table of contents and the current position), and plays the
  tracks into the Mac's sound, at the volume the Mac sets. AppleCD Audio
  Player plays them, and games that play their music from the disc go
  through the same commands. A mixed-mode disc's data track mounts as any
  other disc.

Eject the disc from the Finder (Command-Y or drag it to the Trash), or with
Eject CD in the File menu. A disc dropped on the window replaces the one in
the drive; with Apple's extension the Mac mounts it at once, otherwise
after a restart. ISO, Toast and `.cdr` images are data only.

### Sharing a folder

`--folder ~/MacFiles` (or Host folder in the setup window, or a folder
dropped on the window) puts a folder on the Mac as a hard disk named after
it, with 64 MB or more to spare. The folder and the disk are kept in step
both ways while the Mac runs, every couple of seconds:

- What the Mac does there (new and changed files, new folders, deletes,
  renames and moves) reaches the folder a couple of seconds after the Mac
  stops writing, and on quit. A file only leaves the folder when the Mac
  deleted it (or moved it to the Trash) and it hasn't changed on the host
  since; a folder only when it's empty but for the Finder's `.DS_Store`.
- What changes in the folder on the host (files added, changed, deleted
  or renamed, folders added or deleted) shows on the Mac, in the Finder's
  open windows too: Chime68 has the Mac's own File Manager make the
  change while the Mac waits for events, so the Mac's caches stay right.
- When both sides changed the same file, the host's copy wins; when one
  side deleted a file the other changed, the changed one stays.

With `--read-only` the folder is never changed: what changes on the host
still shows on the Mac, but what the Mac does stays on its disk, in memory.

Limitations:

- The disk can't grow: files added on the host that don't fit in the room
  it was made with are left out (and said so on the terminal).
- A file the Mac has open can't be replaced or deleted from the host; the
  Mac keeps its copy, and the host's goes over when it changes again.
- Files moved to the Mac's Trash leave the folder; putting them back
  brings them back.
- Hidden host files, files with the same name on the Mac as another
  (names are cut to 31 characters), and paths longer than 255 characters
  on the Mac stay out.

Resource forks and the Finder's type and creator travel with the files: on
macOS as the host file's own resource fork and Finder information, elsewhere
in an AppleDouble `._name` file beside it. Files without them get a type
from their extension (`.txt` and other text files open in TeachText). Names
are converted to and from the Mac's character set and cut to 31 characters;
files starting with a period are left out.

## Menus and keys

The emulator's menus are in the host's menu bar: at the top of the screen
on macOS (About and Quit under Chime68), and in the window's menu bar on
Windows, so the whole window is the Mac's screen. The setup window's menus
are there too. Linux has no menu bar for them, so there they are drawn in
the windows, in System 7 style, above the Mac's screen (hidden in full
screen) and the setup dialog. File inserts a disk
image or shares a folder, ejects either floppy or the CD, and saves or restores the
state; Disk Options makes blank disks and mounts images (below); Software
finds software online (see [Finding software online](#finding-software-online)); Machine
resets the Mac, picks the speed and mutes the sound; Gamepad sets up a
game controller (see [Gamepads](#gamepads)); Window goes full screen. Each menu item shows its key, where it has one. None of
them uses Command, which stays the Mac's.

Disk Options makes a blank disk image, asks where to save it, and mounts
it at once, ready to use: the Mac doesn't ask to initialize it. The volume
is named after the file.

| Item                        | Makes                                                     |
|-----------------------------|-----------------------------------------------------------|
| New 400K Floppy             | A single-sided floppy: MFS on the 128K and 512K, whose ROM has no HFS; HFS on the rest |
| New 800K Floppy             | A double-sided HFS floppy (not on the 128K and 512K)      |
| New 1.4 MB Floppy           | An HFS high-density floppy, on Macs with a SuperDrive     |
| New 20 MB ... 2 GB Hard Disk | A bare HFS volume on the SCSI bus, with Chime68's driver (20, 40, 80, 160 and 500 MB, 1 GB, and 2 GB less 1 MB, the most HFS takes before System 7.5); not on the 128K, 512K and 512Ke, which have no SCSI port |
| Mount Disk Image...         | Mounts an existing image, as dropping it on the window does |

Before the Mac starts, the setup window's Create empty disk... button, next
to Add SCSI disk..., makes the same blank hard disks: pick a size, say
where to save it, and it joins the hard disk list.

Hard disk images are held in memory while they're mounted, as every disk
is, so a 2 GB disk takes 2 GB of the host's memory.

In the window the host mouse is the Mac's mouse, and the keyboard is the Mac
Plus keyboard (US layout): Command is Command or Control, Option is Option
or Alt, and the arrows and numeric keypad map to the Mac Plus keypad (on
the SE and Classic, to the ADB keyboard's arrows and keypad). These
keys work the emulator instead:

| Key                    | Does                                                  |
|------------------------|-------------------------------------------------------|
| F5                     | Save the machine's state                              |
| Shift-F5               | Restore the saved state                               |
| F6                     | Save a screenshot (PNG) on the desktop                |
| Shift-F6               | Record the screen as a GIF, or stop recording         |
| F7                     | Rewind 3 seconds (again to go further)                |
| F8                     | Eject the floppy in drive 1                           |
| Shift-F8               | Eject the floppy in drive 2                           |
| Shift-F9               | Press the reset button (RAM and disks are kept)       |
| F10                    | Next speed: 1x, 2x, 4x, 8x, max                       |
| F11, Command-Control-F | Full screen on and off                                |
| F12                    | Switch between the current speed and max              |
| Command-Control-Q      | Quit                                                  |

On a Mac laptop, hold Fn for the F keys (or turn on "Use F1, F2, etc. keys
as standard function keys"). The window title shows the speed the Mac is
running at, and what the last key did.

The screen is drawn at the largest whole-number scale that fits the window
or the display, so each Mac pixel stays a sharp square; resize the window
for a bigger or smaller scale.

## Speed and sound

The Mac runs at the speed of a real Plus (7.8336 MHz, 60.15 frames a
second), paced by the sound card so sound never stutters or drifts.
`--speed 2` runs it twice as fast, `--speed max` as fast as the host can.
Sound only plays at 1x; `--mute` turns it off.

On an Apple Silicon Mac (or another 64-bit ARM host), and on an Intel
Mac or an x86-64 Linux PC, the 68020, 68030 and 68040 Macs run their code
translated to the host's own: Chime68 turns each straight run of 68k
instructions into ARM or x86-64 code the first time it runs, keeps it, and
runs that after, the interpreter taking what isn't translated (exceptions,
the MMU and FPU instructions and the like) without leaving it. It runs the
same to the cycle as the interpreter, devices and all, only faster: about
3.5 times at the Finder and 1.5 times through a boot full of disk and
device traffic, at `--speed max`. `--no-jit` (or `jit = no` in a saved
configuration) leaves it all to the interpreter. (The Intel build run
under Rosetta on an Apple Silicon Mac leaves it off: Rosetta has to
translate the translated code again, which makes it slower than
interpreting. The Apple Silicon build is the one to run there.)

The Macs with a microphone jack (the IIsi, the LCs, the PowerBooks, the
Quadras and Centrises, the AVs) record from the host's microphone: the
Sound control panel's Add... button, SimpleText's Record, HyperCard's
audio palette and the like hear what the host's default input device
hears. Chime68 opens the microphone only while the Mac records (the first
time, macOS asks whether Chime68, or the terminal running it, may use
it), and closes it a couple of seconds after. Machine › Use Microphone
turns it off, and the Mac then records silence.

### Speech

The host says what the Mac's Speech Manager is given, in its own voices:
SimpleText's Speak All, HyperCard's `speak`, the Speech control panel and
any program written for PlainTalk talk on any Mac with System 7, a Plus or
SE as well as a Quadra, with or without the Speech Manager and MacinTalk
installed (Chime68 answers the Speech Manager's calls itself, and tells
the Mac it's there). The Voices menu has MacinTalk's 23 voices, Fred,
Kathy, Ralph, Zarvox, Whisper and the rest; on macOS each is said by the
voice of the same name (the few macOS no longer has, like Victoria, by the
nearest), with the program's rate, pitch and volume and the Speech
Manager's `[[ ]]` commands, which macOS's `say` still takes. Linux uses
`espeak-ng` (or `espeak`) and Windows its own speech synthesizer.
Machine › Speak Aloud turns it off and leaves the Mac to its own Speech
Manager, if it has one; `--no-speech` starts that way. Programs that wait
for the Speech Manager's callbacks (speech done, text done) never hear
them.

At power-on the ROM tests all of RAM (about 28 seconds with 4 MB on a real
Plus). That runs as fast as the host can after the startup chime;
`--no-fast-boot` keeps the real wait. `--ram 1`, `--ram 2.5` or `--ram 4`
(the default) sets the memory size.

## Save states

F5 saves the whole machine (CPU, memory, every chip, and the disks with
everything on them) to `chime68.state` in the current directory, or the
file `--state FILE` names; Shift-F5 restores it, and
`chime68 --rom MacPlus.rom --load-state FILE` starts from it instead of
powering on (its disks come with it, so leave out `--disk` and `--scsi`).
A state needs the ROM it was saved with; the ROM itself isn't in it.

Restoring puts the disks back as they were and rewrites their image files
to match, so changes made to them since the save are lost (as with a VM
snapshot); with `--read-only` the files are left alone. A headless run
(`--frames`) saves its state at the end when `--state` is given.

### Resume where you left off

While a Mac runs, Chime68 keeps its whole state, disks and all, every
three minutes and once more when it quits, so an unexpected quit or a host
restart loses no more than those minutes. The next time, the setup window
shows Resume (the default button) beside Start, which starts over; a
saved configuration started at once, such as a desktop icon's, asks
whether to resume or start over; and `--profile NAME --resume` resumes
without asking. A Mac that was shut down starts afresh. The state is kept
beside the saved configuration, as `NAME.resume` in the `Configurations`
folder; a setup without a name keeps the last one in
`Resume/unnamed.resume`. Like a save state, resuming puts the disks back
as they were when it was kept.

### Rewind

F7 (Machine › Rewind 3 Seconds) takes the Mac back three seconds, and
pressing it again goes three more, up to ten seconds back: missed a jump,
closed the wrong window, or a program just crashed. Chime68 keeps a
rewind point every second of the Mac's time, in memory, without the
disks' contents; instead it keeps what each write to a hard disk
overwrote, so going back puts the disks as they were too, and saves them
that way to the image files. Floppies come back as they were with the
rest. Attaching or ejecting a disk starts the rewind points over, as does
restoring a save state.

## Recording the screen

Shift-F6 (Window › Record Screen as GIF) records the screen to an
animated GIF on the desktop, at 20 frames a second, until Shift-F6 again.
Each frame holds only what changed, in the screen's own colours, so a
recording of the Finder stays small. Window › Record Screen as MP4
records a video with the sound instead (twice the size, the pixels kept
sharp), made by [ffmpeg](https://ffmpeg.org), which has to be installed
(`brew install ffmpeg`); the menu item is dimmed without it. Recordings
keep the Mac's own time, so one made at max speed plays back at the
Mac's real speed. Changing the screen's size ends a recording.

## Debugging

`--debug stdio` opens a debugger console on the terminal, `--debug tcp:PORT`
one on 127.0.0.1 (connect with `nc 127.0.0.1 PORT`), and `--gdb PORT` a GDB
remote stub. Any of them starts the Mac paused at its first instruction;
`c` lets it go. Console commands take hex numbers:

| Command              | Does                                                     |
|----------------------|----------------------------------------------------------|
| `r`                  | Registers and flags                                      |
| `set REG VALUE`      | Changes `d0`-`d7`, `a0`-`a7` (`sp`), `sr` or `pc`        |
| `s [N]`, `c`, `p`    | Step N instructions, continue, pause                     |
| `u [ADDR] [N]`       | Disassembles N instructions (10) from ADDR (the PC)      |
| `m ADDR [LEN]`       | Dumps memory (devices show as `--`)                      |
| `w ADDR BYTE...`     | Writes bytes into RAM                                    |
| `b ADDR`             | Breaks when the PC gets there                            |
| `bw`/`br`/`ba ADDR [LEN]` | Stops after an instruction writes, reads or touches the range |
| `l`, `d ADDR`        | Lists breakpoints, deletes those at ADDR                 |

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --debug stdio
```

With `--gdb 1234` and a GDB for the 68000 (`m68k-elf-gdb`, or
`gdb-multiarch` on Linux):

```text
(gdb) set architecture m68k
(gdb) target remote localhost:1234
(gdb) break *0x400100
(gdb) watch *(int *)0x108
(gdb) continue
```

The debugger works headless too (`--frames N --debug ...`), and the window
shows "paused in the debugger" in its title while the Mac is stopped. A
read watchpoint also fires on instruction fetches from its range.
Breakpoints, disassembly and memory dumps take the addresses the program
uses (32-bit on the Mac II family, through the MMU when it's on);
watchpoints take the bus's 24-bit ones.

### The debugger's window

Debugger in the Window menu (or `--debug window`, which starts the Mac
paused) opens a window beside the Mac's, in the setup window's System 7
look: the code from the PC, with the PC's line in black (click a line to
set or clear a breakpoint there; the scroll arrows move through the code,
and a click between them goes back to the PC); the registers and flags
(click one to see the memory it points at); the breakpoints and
watchpoints, the console's and GDB's too (click one to take it away); and
96 bytes of memory, from the address typed in the field. Run, Pause, Step
and Step Over (which runs a JSR, BSR or trap through) drive the Mac; with
the window in front, `R`, `S` and `O` do the same, hex digits go in the
address field and Return shows the memory there. Closing the window lets
the Mac carry on (taking its breakpoints with it, unless `--debug` or
`--gdb` is running too).

## Scripting

`--control PATH` opens a control socket (a Unix socket at PATH, or
`tcp:PORT` on 127.0.0.1) that a script drives the Mac through, and
`--headless` runs the Mac without a window until the script says `quit`.
`chime68 ctl` sends the commands, one per call, prints what comes back and
exits 1 if the command failed, so a shell script can stop at the first
thing that didn't happen:

```sh
chime68 ctl boot "System 7"            # a saved configuration, headless
chime68 ctl wait-text Trash 120        # the Finder is up
chime68 ctl menu File "New Folder"
chime68 ctl type "Hello"
chime68 ctl key return
chime68 ctl screenshot finder.png
chime68 ctl quit
```

`ctl boot` starts Chime68 on a configuration saved in the setup window (or
a `.chime68` file) in the background, `--window` to see it, with any other
options after the name (`--speed max` runs a script as fast as the host
can), its output in a log beside the socket; it returns once the socket
answers. `ctl run SCRIPT` runs a file of commands, one a line (paths in it
from the script's folder), stopping at the first that fails: [scripts/smoke-test.ctl](scripts/smoke-test.ctl) is
a smoke test that boots, makes a folder in the Finder and saves a
screenshot, the kind of thing a CI job can run. CI runs
[scripts/ci-smoke.ctl](scripts/ci-smoke.ctl) on every push, which needs no
Apple ROM: it boots the little ROM [scripts/make-test-rom.py](scripts/make-test-rom.py)
writes, which draws a pattern, and compares the screenshot with
[tests/smoke/expected.png](tests/smoke/expected.png). The socket is
`$CHIME68_CONTROL`, or `chime68-control.sock` in the temporary folder
(`--socket` picks another; a Unix socket's path has to be short, about
100 characters); `$CHIME68_CONFIG_DIR` keeps a run's PRAM and
configurations apart from yours.

| Command                          | Does                                                    |
|----------------------------------|---------------------------------------------------------|
| `move X Y`                       | Puts the pointer there (the Mac's screen coordinates)   |
| `click [X Y]`, `dclick [X Y]`    | Clicks or double-clicks there, or where the pointer is  |
| `down`/`up [X Y]`, `drag X1 Y1 X2 Y2` | Presses or releases the button; drags             |
| `type TEXT`                      | Types it on the Mac's U.S. keyboard                     |
| `key KEY...`                     | `a`, `return`, `tab`, `escape`, `left`, `cmd-q`, `cmd-shift-3`, `0x24` |
| `wait SECONDS`                   | Lets the Mac run (seconds of the Mac's time)            |
| `wait-text TEXT [TIMEOUT]`       | Until the text is on the screen; says where             |
| `wait-gone TEXT [TIMEOUT]`       | Until it isn't                                          |
| `find-text TEXT`                 | Where the text is now (`X Y WIDTH HEIGHT FONT`)         |
| `click-text TEXT [TIMEOUT]`      | Waits for the text, then clicks its middle              |
| `menu TITLE ITEM [TIMEOUT]`      | Chooses a menu item by name                             |
| `wait-pixel X Y COLOR [TIMEOUT]` | Until the pixel is `RRGGBB`, `black` or `white`         |
| `pixel X Y`                      | The pixel's colour                                      |
| `screenshot FILE.png`            | Saves the screen                                        |
| `snapshot list`                  | The named snapshots (`--snapshot`), a `-` for each level down, `*` on the current one |
| `snapshot take NAME`             | Keeps the disks as they are now as `NAME`               |
| `snapshot rollback NAME`         | Puts the disks back as in `NAME` and restarts the Mac   |
| `snapshot branch NAME`           | The same, keeping where the disks were as a snapshot first |
| `snapshot delete NAME`           | Deletes the snapshot `NAME`                             |
| `info`, `ping`, `quit`           | The model, screen and pointer; whether it's there; quit, saving the disks |

Text with spaces goes in quotes, and waits give up after 30 seconds unless
told otherwise. Text is found by drawing it in the ROM's own fonts and
looking for that on the screen, black on light or white on dark: Chicago
12 on every Mac, and Geneva 9 and 12 and Monaco 9 from the SE on, which
is what menus, dialogs, window titles and the Finder's icons use. Text in
other fonts or styles, or dimmed, isn't found.

## Serial ports

`--modem` and `--printer` plug the Mac's serial ports into:

- `pty`: a new pseudo-terminal, whose path is printed (macOS and Linux);
  open it with `screen` or `minicom`;
- `file:PATH`: what the Mac sends is appended to the file, and nothing comes
  back. Pick the ImageWriter on the printer port in the Chooser and what the
  Mac prints lands in the file as ImageWriter commands;
- `tcp:HOST:PORT`: a TCP connection, both ways;
- `pdf` or `pdf:FOLDER`: an ImageWriter II that prints to PDF files (PDF
  on the printer port in the setup window); see below;
- `laserwriter` or `laserwriter:FOLDER` (printer port): a LaserWriter on
  LocalTalk that prints to PDF files (LaserWriter in the setup window);
  see below;
- `midi` or `midi:NAME` (macOS): a MIDI interface (MIDI on the modem port
  in the setup window); see below.
- `ppp`: a modem with the Internet behind it, speaking PPP or SLIP
  (Internet on the modem port in the setup window); see [Dial-up: PPP and
  SLIP](#dial-up-ppp-and-slip).

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --modem pty --printer file:printer.out
```

### Printing to PDF

With `--printer pdf`, choose ImageWriter in the Chooser, on the printer
port, and print as usual: each job becomes a PDF, `Chime68 Print 1.pdf`,
`Chime68 Print 2.pdf` and so on, on the host's Desktop (or in the folder
`pdf:FOLDER` names). Chime68 puts the ImageWriter's dots on letter-size
pages as the printer would: Faster at 72 dots an inch, Best at 144, and
Draft in the printer's own characters. A job's file is complete after each
page; the next job starts a new file once the Mac has been quiet for a few
seconds.

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --printer pdf
```

### A LaserWriter

`--printer laserwriter` (or LaserWriter on the printer port in the setup
window) puts a LaserWriter on the Mac's LocalTalk network that prints to
PDF files: turn AppleTalk on in the Chooser, pick LaserWriter (or
LaserWriter 8), and "Chime68 LaserWriter" is there to choose, beside the
ImageWriter (on LaserWriter 8, click Setup... once, and Auto Setup asks the
printer what it is). Print as usual, and each job becomes a PDF, `Chime68
Print 1.pdf` and on, on the host's Desktop (or in the folder
`laserwriter:FOLDER` names).

The printer is a PostScript interpreter inside Chime68, drawing into
PDF: lines, shapes and pictures stay as they are, at any size, and text in
the printer's own fonts stays text you can select and search. It says it's
a LaserWriter II NT (PostScript 47.0, 300 dots an inch) with its 35 fonts:
Times, Helvetica, Courier, Symbol and Zapf Dingbats are PDF's own, and the
rest (Palatino, Bookman, New Century Schoolbook, Avant Garde, Zapf
Chancery, Helvetica Narrow) are drawn in the nearest of those. Fonts the
Mac sends along (bitmap fonts, and TrueType and Type 1 fonts the driver
turns into PostScript) are drawn as the Mac sends them. Colour comes out
in colour. The LaserWriter drivers of System 6 and 7 (LaserWriter 7 and
LaserWriter 8) set it up the first time they print, as they did a real
one, and errors in a job come back to the Mac as a real printer's did.

The printer is a node on LocalTalk (LToUDP) like the AppleShare server,
so the printer port is on LocalTalk too, and every Chime68 on the
machine sees it.

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --printer laserwriter
```

### MIDI

With `--modem midi`, the modem port has a MIDI interface on it, as Apple's
MIDI Interface did: it clocks the port at MIDI's 31,250 baud, so MIDI
software set up for an interface at 1 MHz on the modem port (MIDI Manager
and Apple MIDI Driver, Opcode's OMS, or programs of their own) plays
through it. The MIDI goes to CoreMIDI, to a source and a destination both
called "Chime68": pick Chime68 as the input of a synthesizer or sequencer
on the Mac you're running Chime68 on (GarageBand, Logic, a soft synth) to
hear it, and as an output to play into the old Mac. `midi:NAME` connects
straight to the MIDI device whose name has `NAME` in it instead (an
interface with a real synthesizer on it, say), both ways.

```sh
chime68 --rom MacII.rom --scsi System7.img --modem midi
```

## Gamepads

A game controller on the host (Xbox, PlayStation, Switch Pro and most USB
and Bluetooth pads) plays the Mac's games, as the Gamepad menu sets it up:

- **Moves the Mouse**: the left stick moves the pointer (further, faster),
  the d-pad nudges it, and A clicks;
- **Presses the Arrow Keys**: the stick and the d-pad press the arrow keys,
  and A presses Space;
- **Presses Chosen Keys**: the stick and the d-pad press the keys chosen
  for up, down, left and right.

Out of the box B presses Return, X Space (or clicks, with the keys), Y
Escape, Start Return, Select Tab, the shoulder buttons Shift and Option and
the left trigger Command. To choose others, pick Choose a Key for a
Control..., press a button (or the d-pad) on the gamepad, then the key on
the host's keyboard (or click, for the mouse button); go on with the next,
and pick Stop Choosing Keys when done. Forget Chosen Keys goes back to the
usual ones.

The mode and the keys are kept with the configuration: a game's saved
configuration (and its desktop launcher) comes up with its own, as
`gamepad` and `gamepad_keys` in its file, such as `gamepad = keys` and
`gamepad_keys = up:w down:s left:a right:d a:space b:click`.

## Keyboard layouts

The Mac's keyboard types what its System's layout says, the U.S. one
unless the Keyboard control panel picks another. Sent key by key, a host
keyboard with another layout types what the Mac's keys in its keys' places
would (on a U.S. Mac, a Spanish keyboard's Ñ types a semicolon).

With Machine › Translate Keyboard Layout on:

- The Mac takes the layout that matches the host's, as if picked in its
  Keyboard control panel, when its System has one: Español ISO (or
  Español) for a Spanish or a Latin American keyboard, and French,
  German, Italian, British, Swedish and the others the U.S. System 7 comes
  with for theirs. Keys sent key by key, Command shortcuts among them, then
  type what they say on the host. The Mac keeps it until it restarts
  (Chime68 picks it again then).
- A key that types a character on the host types that character on the
  Mac, whatever layout the Mac has: Chime68 reads the layout's `KCHR` from
  the Mac and sends the keys that type it there, with Shift and Option and
  a dead key first for an accented letter (on the U.S. layout, Option-N
  then N for ñ, Option-E then A for á, Option-Shift-/ for ¿). Keys that
  type nothing, like the arrows and Return, and everything typed with
  Command still go key by key.

The host's layout is the current macOS input source, Windows keyboard
layout or X layout (`setxkbmap -query`, or `XKB_DEFAULT_LAYOUT`), looked at
every few seconds, so switching it on the host switches the Mac's too, and
a layout picked in the Mac's Keyboard control panel is followed. The
setting is kept for next time in `keyboard.cfg` in the configuration
folder, where a line like `layout = spanish` stands in for the host's
layout (`us`, `british`, `french`, `german`, `italian`, `spanish`,
`latin-american`, `swedish`, `danish`, `norwegian`, `finnish`, `dutch`,
`belgian`, `portuguese`, `swiss-french`, `swiss-german`,
`canadian-french`, `canadian-csa`, `australian`).

## LocalTalk

`--localtalk` puts the printer port on LocalTalk, carried over UDP
multicast as LToUDP (group 239.192.76.84, port 1954), the bridge Mini vMac
and the AppleTalk routers jrouter and
[tashrouter](https://github.com/lampmerchant/tashrouter) use. Every Chime68
(and Mini vMac) on the LAN is then on the same LocalTalk network.
`--localtalk-if 192.168.1.20` picks the network interface by its address
(`127.0.0.1` keeps it to emulators on this machine).

Turn AppleTalk on in the Chooser (choose Active), and the Mac takes a node
address. To reach AppleShare servers and printers on Ethernet, run the
LocalTalk bridge (below), or a router that speaks LToUDP on one side and
EtherTalk on the other (jrouter or tashrouter, on a Linux box or Raspberry
Pi), with netatalk 4 (which has AppleTalk again) for file sharing. The
servers and printers then show up in the Chooser.

Two Chime68 windows on one machine are on the same LocalTalk network
with `--localtalk` on both (add `--localtalk-if 127.0.0.1` to keep it to
this machine): turn on File Sharing on one (System 7) and the other sees
it in the Chooser, or play a networked game between them.

### The AppleShare server

`--appleshare FOLDER` (or File › Share Folder over AppleShare..., while
the Mac runs) shares a folder on the host from an AppleShare server
inside Chime68. In the Chooser, pick AppleShare, then "Chime68", connect
as a guest and check the folder: it mounts like any file server's
volume, and the Mac reads, writes, makes, renames and deletes the files
in it directly, as they are on the host. Share more folders and each is
another volume of the same server; `--appleshare` can be given more than
once.

The server is a node on LocalTalk (LToUDP), so it puts the Mac's printer
port on LocalTalk too, if nothing else is plugged in there. Every
Chime68 on the machine, and on the LAN with `--localtalk`, sees it; a
Mac on EtherTalk sees it through the LocalTalk bridge below. Any Mac
with AppleShare's Chooser extension can use it: System 6 and 7's
AppleShare client speaks the AFP 2 the server does. Resource forks and
Finder information go where a shared folder keeps them (the file's own
on macOS, an AppleDouble `._name` file elsewhere), and names are
converted between Mac Roman and UTF-8.

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --appleshare ~/Documents/Mac
```

### The LocalTalk bridge

`--localtalk-bridge` (or LocalTalk bridge in the setup window) runs an
AppleTalk router inside Chime68, between LocalTalk (LToUDP) and the
Ethernet multicast group (see below), so a Plus, SE or Classic on
LocalTalk sees the Quadra's, IIci's or netatalk's AppleShare servers on
EtherTalk, and they see it. It is a seed router, as Apple's LocalTalk
Bridge was: LocalTalk is network 1 and EtherTalk 2, in one zone,
"Chime68". Any one Chime68 on the LAN can run it, whatever Mac it is
(or none: `chime68 --localtalk-bridge` alone runs only the bridge, until
you stop it). Run one per LAN, and start it before the Macs on
EtherTalk, which ask for their network when AppleTalk starts.

```sh
chime68 --rom MacPlus.rom --scsi System755.dsk --localtalk --localtalk-bridge
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --scsi System7.dsk --ethernet
```

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --localtalk
```

AppleTalk stays on from one run to the next, since the PRAM is kept.

## Ethernet

`--ethernet` (or Ethernet: Multicast in the setup window) gives the Mac
Ethernet on a UDP multicast group, 230.0.0.1 port 1234
(`--ethernet-group` for another), with no privileges needed: every frame
goes, as it is, to the group, and every Chime68 on the LAN using that
group is on the same Ethernet. It's what QEMU's
`-netdev socket,mcast=230.0.0.1:1234` speaks, so a QEMU Quadra 800 or
another guest can join too. The Quadras use their built-in Ethernet (the
SONIC chip, and the 840AV's and 660AV's MACE); the Mac II, II FDHD, IIx, IIcx and IIci get an Ethernet card in NuBus
slot $C, and the SE/30 one in its processor-direct slot, built like Apple's
EtherTalk NB card so the System's own driver runs it.

In the Network control panel, pick EtherTalk (Built-In, or the card) and
AppleTalk runs over it: AppleShare between two Chime68s works (turn File
Sharing on in Sharing Setup on one, and pick it in the other's Chooser).
MacTCP can use it too (pick Ethernet in its control panel and give each Mac
an address); reaching the host's network or the Internet takes a host on
the group that routes, such as a QEMU or Linux VM on it, or the Internet
setting below.

Each run picks a new Ethernet address in Apple's 08:00:07 block;
`--ethernet-address 08:00:07:12:34:56` keeps one, and `--ethernet-if`
picks the network interface by its address.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --scsi System7.dsk --ethernet
```

### The Internet

`--internet` (or Ethernet: Internet in the setup window) plugs the Mac's
Ethernet into a NAT inside Chime68 instead, like QEMU's user networking:
no root, nothing to set up on the host, and the Mac reaches whatever the
host can, the Internet included. The Mac is alone on a private network,
10.0.2.0/24:

| | |
|---|---|
| The Mac | 10.0.2.15 |
| Router (and the host itself) | 10.0.2.2 |
| Name server | 10.0.2.3 |
| Subnet mask | 255.255.255.0 |

In MacTCP's control panel, pick Ethernet, click More... and choose Server
(BOOTP hands the Mac its address, mask and router), and put 10.0.2.3 in
the name server list as the default; or choose Manually and type the
addresses above. Open Transport's TCP/IP control panel takes "Using DHCP
Server". Then Fetch, Netscape, NCSA Telnet and the like work. Each TCP
connection and UDP port the Mac opens is made again by Chime68 from the
host, so 10.0.2.2 reaches the host's own servers (it is 127.0.0.1 to
them), and names are looked up with the host's resolver. Pings to
10.0.2.2 are answered, and pings elsewhere go out where the host lets a
program ping without privileges (macOS does). Only the Mac starts
connections: nothing outside can reach a server on it.

```sh
chime68 --rom "420DBFF3 - Quadra 700&900 & PB140&170.ROM" --scsi System7.dsk --internet
```

#### The web proxy

Today's web is HTTPS, and Netscape 2 and 3, iCab and MacWeb know none of
the encryption servers still take, so with `--internet` the Mac's web
requests go through a proxy inside Chime68. It takes every connection
the Mac makes to port 80, so there is nothing to set up: type an
`http://` address, and the proxy fetches the page over HTTPS where the
server has it (and over plain HTTP where it doesn't), then reworks it for
an old browser:

- `https://` links, forms and redirects become `http://` ones, which come
  back to the proxy, so following links works;
- scripts, style sheets, SVG, inline frames, video and the attributes old
  browsers trip on are taken out, the newer block elements (`header`,
  `nav`, `section` and the like) become `div`s, and a picture that loads
  late (from `data-src` or `srcset`) gets its real address;
- the text comes as ISO 8859-1, which the browsers show in Mac Roman;
  curly quotes, dashes and the letters Latin-1 lacks become their
  nearest ASCII, and emoji are left out;
- pictures wider than 640 or taller than 800 pixels are shrunk, and PNG,
  WebP and progressive JPEG pictures (which the old browsers can't show)
  become GIFs (when they have transparency or few colours) or baseline
  JPEGs;
- the answer is HTTP/1.0 with its length up front and only the headers
  old browsers know, and cookies lose `Secure` and `SameSite`, so logins
  that remember you keep working.

A browser that can be told to use a proxy can also be pointed at
10.0.2.4 (any port), which reaches pages on other ports too. What isn't a
web request goes through to port 80 as it is. Machine › Web Proxy turns
the proxy off and on while the Mac runs, and `--no-web-proxy` starts
without it.

#### Mail

Eudora, Claris Emailer and the other mail programs of the time speak POP3,
IMAP and SMTP in the clear with a plain password, which today's mail
servers turn away. Give Chime68 the account and its servers, and its mail
bridge takes the Mac's connections to the mail ports (110, 143, 25 and
587, on any server name, or 10.0.2.5) and talks to the real servers over
TLS (from the start on 995, 993 and 465, after STARTTLS on other ports),
logging in with the account's name and password whatever the Mac sends:

```sh
chime68 --rom Quadra700.rom --scsi System761.dsk --internet \
  --mail-imap imap.gmail.com --mail-smtp smtp.gmail.com \
  --mail-user me@gmail.com --mail-password "abcd efgh ijkl mnop"
```

Each server is `host` or `host:port` (995 for POP3, 993 for IMAP and 465
for SMTP when no port is given); `--mail-pop` sets a POP3 server.
`CHIME68_MAIL_PASSWORD` gives the password instead of the command line.
The account is kept with a saved configuration (`mail_user`,
`mail_password`, `mail_pop`, `mail_imap` and `mail_smtp`), in a file
only you can read; most services want an app password rather than the
account's own. On the Mac, set the incoming and outgoing servers to
anything (the real names are fine), with any user name and password, and
no SSL. For SMTP the bridge logs in itself and answers the program's
EHLO and AUTH; for POP3 and IMAP without a name and password in
Chime68's setup, the program's own are used.

#### SCSI Ethernet: the Plus, SE and Classic

A Mac with no slot for an Ethernet card (the Plus, SE, Classic, Portable,
PowerBooks, and the LCs and Classic II here) gets a SCSI Ethernet adapter
instead with `--ethernet` or `--internet`: an emulated DaynaPORT
SCSI/Link, the adapter BlueSCSI, ZuluSCSI and PiSCSI emulate too, at the
highest free SCSI ID. The Mac needs Dayna's driver for it (DaynaPORT
SCSI/Link's "DaynaPORT Drivers" installer, the one those projects point
to), which puts the adapter in MacTCP's control panel (or Open Transport's
AppleTalk and TCP/IP ones) as Ethernet. Set it up there as for any
Ethernet above: Server (BOOTP) or the addresses by hand, and 10.0.2.3 as
the name server. A save state doesn't hold the adapter; it stays plugged
in across one.

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --internet
```

#### Dial-up: PPP and SLIP

A Plus, SE, Classic, Portable or PowerBook had no Ethernet of its own,
but it could dial up, as these Macs did. `--modem ppp` (or Internet on the
modem port in the setup window) puts a modem on the modem port with
Chime68's NAT behind it. The modem answers the Hayes commands modem scripts send and says
CONNECT at 57,600 baud whatever number is dialled, then speaks PPP (or
SLIP) as a dial-up provider did. The Mac is on the same private network as
with Ethernet, with the same web proxy:

| | |
|---|---|
| The Mac | 10.0.2.15 |
| Router | 10.0.2.2 |
| Name server | 10.0.2.3 |

- **Open Transport PPP** (Mac OS 7.6 and 8, or OT/PPP on 7.5): in the
  Modem control panel, choose the Modem Port and any Hayes-compatible
  modem; in TCP/IP, connect via PPP, configure Using PPP Server and put
  10.0.2.3 under Name server addr. In the PPP control panel, connect as a
  Guest (or with any name and password) to any number.
- **MacPPP or FreePPP with MacTCP**: in MacTCP, pick PPP and choose
  Server; in Config PPP, the modem port at 57600, any phone number, and
  10.0.2.3 as the name server; then Open.
- **SLIP** (InterSLIP, MacSLIP): set the Mac's address to 10.0.2.15 and its
  gateway and name server as above, with no header compression (plain
  SLIP, not CSLIP), and no login script.

Any name and password are taken, Van Jacobson header compression is turned
down (the Mac then goes without), and hanging up or a script's AT command
drops the line, ready to dial again.

```sh
chime68 --rom MacSE.rom --scsi System7.dsk --modem ppp
```

#### Dialing a BBS

The same modem calls a host instead when it's dialled by name: `ATDT
bbs.example.com` in ZTerm, MacTerminal, Microphone or any terminal program
opens a telnet connection there (`ATDT host:2323` or `ATDT host 2323` for
another port), says CONNECT, and from then on what the Mac types goes to
the host and what the host sends comes back, as with the telnet BBSes of
today. Telnet's options are answered for a terminal (the host echoes, a
character at a time, a VT100 of 80 by 24); a port that isn't telnet's
gets the bytes as they are, unless the host starts negotiating. `+++` with
a second's pause either side goes back to commands with the call up
(`ATO` returns to it, `ATH` hangs up), and NO CARRIER means the host hung
up. Plain numbers still reach the PPP provider.

A program that only dials digits can use the phone book, numbers that call
hosts, kept with a saved configuration as `phone` lines or given with
`--phone`:

```sh
chime68 --rom MacPlus.rom --scsi System608.dsk --modem ppp --phone 5551234=bbs.fozztexx.com
```

```text
phone = 5551234 bbs.fozztexx.com
phone = 5550199 particlesbbs.dyndns.org:6400
```

## PRAM

Like a real Mac's battery-backed PRAM, the settings the Control Panel and
the Chooser keep there (AppleTalk on or off, the alert sound, the mouse
and keyboard speeds) are kept between runs, one set per model, in `pram/` next to the setup file:
`~/Library/Application Support/Chime68` on macOS, `%APPDATA%\Chime68` on
Windows and `~/.config/chime68` elsewhere (or `$CHIME68_CONFIG_DIR`). To
zap the PRAM, delete the model's file there while Chime68 isn't running.
A save state carries the PRAM it was saved with.

## Headless runs

`--frames N` runs N frames without a window, as fast as it can, then prints
the emulated and wall time, the CPU state and the hottest PCs of the last
frame (where the ROM is stuck, if it is). `--trace N` also prints the first
N instructions of that frame, `--screenshot FILE.pbm` saves the screen, and
`--wav FILE.wav` the sound (the boot beep is in the first second).

```sh
chime68 --rom MacPlus.rom --frames 600 --trace 200 --screenshot screen.pbm
```

## In a browser

Chime68 also runs in a web browser, as WebAssembly. Build it with

```sh
scripts/build-web.sh
```

(it needs Rust's `wasm32-unknown-unknown` target, which the script adds
with rustup if it's missing, and nothing else), then serve `target/web`
over HTTP and open it:

```sh
python3 -m http.server -d target/web 8068
```

and go to http://localhost:8068. Pick a ROM of your own Mac and disk
images (floppies, hard disk images and CDs) with the page's file inputs:
they're kept in the browser's storage (IndexedDB), so the next visit has
them, and nothing leaves the browser. Choose the machine and memory, and
Start. The keyboard and mouse work on the Mac's screen (click it first),
and the sound plays through Web Audio. What the Mac writes to its disks
is saved back to the browser's copies, and the PRAM is kept per ROM; the
images on your own disk aren't touched. There is no networking, serial
port or printer in the browser, and no setup window, debugger or save
states.

The module (`crates/chime68-web`) is the emulator with a small C-style
interface for the page (`web/chime68.js`), with no bindings generator; the
native app is built as before.

## Layout

| Crate            | What it is                                                   |
|------------------|--------------------------------------------------------------|
| `crates/m68k`    | 68000 CPU core behind a `Bus` trait; no Mac knowledge        |
| `crates/macplus` | The Plus, SE, Classic and Mac II: memory map, ROM, chips, input, frame timing |
| `crates/chime68` | Front end binary: window (winit), sound (cpal), headless runner |
| `crates/chime68-web` | The emulator as WebAssembly, for the page in `web/` |

How they fit together is in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Testing

```sh
cargo test                     # unit and integration tests
CHIME68_ROM=path/to/MacPlus.rom cargo test --release -p macplus --test rom_boot
# also boot a System 6 hard disk volume to the Finder and drive it with
# the mouse and keyboard
CHIME68_ROM=path/to/MacPlus.rom CHIME68_SYSTEM_VOLUME=path/to/disk.dsk cargo test --release -p macplus --test rom_boot
# boot the same volume over SCSI, bare and as a partitioned disk
CHIME68_ROM=path/to/MacPlus.rom CHIME68_SYSTEM_VOLUME=path/to/disk.dsk cargo test --release -p macplus --test scsi_boot
# print a directory from the Finder through the printer port
CHIME68_ROM=path/to/MacPlus.rom CHIME68_SYSTEM_VOLUME=path/to/disk.dsk cargo test --release -p macplus --test serial
# the SE, SE FDHD and Classic: boot a floppy and the volume over SCSI, and
# drive the Finder through ADB (each runs only if its ROM is given)
CHIME68_SE_ROM=SE.rom CHIME68_SE_FDHD_ROM=SEFDHD.rom CHIME68_CLASSIC_ROM=Classic.rom \
  CHIME68_SYSTEM_VOLUME=path/to/disk.dsk cargo test --release -p macplus --test models
./scripts/fetch-sst.sh         # downloads the 68000 SingleStepTests (~200 MB)
CHIME68_SST_DIR=test-data/680x0 cargo test -p m68k --release --test single_step -- --nocapture
```

## Contributing

PR titles follow Conventional Commits, each `feat:` or `fix:` PR bumps the
version and adds its line to [CHANGELOG.md](CHANGELOG.md), and releases are
tagged by hand. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT. See [LICENSE](LICENSE). The machine icons in the setup window are
from the Iconfactory's Apple Desktop and Apple Portables Collections,
© 1998 the Iconfactory, used with their permission.
